<?php
class UserManager {
    private $db;
    private $security;
    
    public function __construct($database) {
        $this->db = $database;
        $this->security = new SecurityManager();
    }
    
    public function register($user_data) {
        // E-posta kontrolü
        if ($this->getUserByEmail($user_data['email'])) {
            return ['success' => false, 'message' => 'email_exists'];
        }
        
        // Şifre kontrolü
        if (strlen($user_data['password']) < 6) {
            return ['success' => false, 'message' => 'password_requirements'];
        }
        
        // Email validasyonu
        if (!$this->security->validateEmail($user_data['email'])) {
            return ['success' => false, 'message' => 'invalid_email'];
        }
        
        // Kullanıcıyı kaydet
        $user_data['password'] = $this->security->hashPassword($user_data['password']);
        $verification_token = $this->security->generateToken();
        
        $sql = "INSERT INTO users (name, email, password, company, phone, verification_token) VALUES (?, ?, ?, ?, ?, ?)";
        $result = $this->db->query($sql, [
            $user_data['name'],
            $user_data['email'],
            $user_data['password'],
            $user_data['company'] ?? '',
            $user_data['phone'] ?? '',
            $verification_token
        ]);
        
        if ($result) {
            // Kullanıcıyı otomatik giriş yap
            $user = $this->getUserByEmail($user_data['email']);
            unset($user['password']);
            $_SESSION['user'] = $user;
            
            // Email doğrulama gönder (simülasyon)
            $this->sendVerificationEmail($user_data['email'], $verification_token);
            
            return ['success' => true, 'message' => 'register_success'];
        }
        
        return ['success' => false, 'message' => 'unknown_error'];
    }
    
    public function login($email, $password) {
        // Brute force kontrolü
        if ($this->security->checkBruteForce($email)) {
            return ['success' => false, 'message' => 'too_many_attempts'];
        }
        
        $user = $this->getUserByEmail($email);
        
        if ($user && $this->security->verifyPassword($password, $user['password'])) {
            if ($user['status'] !== 'active') {
                $this->security->recordLoginAttempt();
                return ['success' => false, 'message' => 'account_inactive'];
            }
            
            // Son giriş zamanını güncelle
            $this->updateLastLogin($user['id']);
            
            // Başarılı girişte attempt'leri temizle
            $this->security->clearLoginAttempts();
            
            unset($user['password']);
            $_SESSION['user'] = $user;
            return ['success' => true, 'message' => 'login_success'];
        }
        
        // Başarısız giriş attempt'ini kaydet
        $this->security->recordLoginAttempt();
        return ['success' => false, 'message' => 'login_error'];
    }
    
    public function logout() {
        unset($_SESSION['user']);
        session_destroy();
        return true;
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user']);
    }
    
    public function getUser() {
        return $_SESSION['user'] ?? null;
    }
    
    public function getUserByEmail($email) {
        $sql = "SELECT * FROM users WHERE email = ?";
        $result = $this->db->query($sql, [$email]);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return null;
    }
    
    public function getUserById($user_id) {
        $sql = "SELECT * FROM users WHERE id = ?";
        $result = $this->db->query($sql, [$user_id]);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return null;
    }
    
    public function updateUser($user_id, $user_data) {
        $sql = "UPDATE users SET name = ?, company = ?, phone = ?, company_size = ?, industry = ? WHERE id = ?";
        $result = $this->db->query($sql, [
            $user_data['name'],
            $user_data['company'],
            $user_data['phone'],
            $user_data['company_size'],
            $user_data['industry'],
            $user_id
        ]);
        
        if ($result) {
            // Session'ı güncelle
            $user = $this->getUserById($user_id);
            unset($user['password']);
            $_SESSION['user'] = $user;
            return true;
        }
        
        return false;
    }
    
    public function changePassword($user_id, $current_password, $new_password) {
        $user = $this->getUserById($user_id);
        
        if ($user && $this->security->verifyPassword($current_password, $user['password'])) {
            if (strlen($new_password) < 6) {
                return ['success' => false, 'message' => 'password_requirements'];
            }
            
            $new_password_hash = $this->security->hashPassword($new_password);
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            $result = $this->db->query($sql, [$new_password_hash, $user_id]);
            
            if ($result) {
                return ['success' => true, 'message' => 'password_changed'];
            }
        }
        
        return ['success' => false, 'message' => 'invalid_current_password'];
    }
    
    public function upgradePlan($user_id, $new_plan) {
        $valid_plans = ['personal', 'lite', 'pro', 'pro_max', 'ultimate'];
        if (!in_array($new_plan, $valid_plans)) {
            return false;
        }
        
        $sql = "UPDATE users SET plan = ? WHERE id = ?";
        $result = $this->db->query($sql, [$new_plan, $user_id]);
        
        if ($result) {
            // Session'ı güncelle
            $user = $this->getUserById($user_id);
            unset($user['password']);
            $_SESSION['user'] = $user;
            
            // Sipariş kaydı oluştur
            $this->createOrder($user_id, $new_plan);
            return true;
        }
        
        return false;
    }
    
    private function createOrder($user_id, $plan) {
        $plan_prices = [
            'personal' => 0,
            'lite' => 29,
            'pro' => 79,
            'pro_max' => 149,
            'ultimate' => 299
        ];
        
        $amount = $plan_prices[$plan] ?? 0;
        
        $sql = "INSERT INTO orders (user_id, plan_type, amount, payment_status) VALUES (?, ?, ?, 'completed')";
        $this->db->query($sql, [$user_id, $plan, $amount]);
    }
    
    private function updateLastLogin($user_id) {
        $sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
        $this->db->query($sql, [$user_id]);
    }
    
    public function canAccessProduct($user_plan, $required_plan) {
        $plan_hierarchy = [
            'personal' => 1,
            'lite' => 2,
            'pro' => 3,
            'pro_max' => 4,
            'ultimate' => 5
        ];
        
        return ($plan_hierarchy[$user_plan] ?? 0) >= ($plan_hierarchy[$required_plan] ?? 0);
    }
    
    public function recordDownload($user_id, $product_id) {
        // Önce kayıt var mı kontrol et
        $check_sql = "SELECT * FROM user_downloads WHERE user_id = ? AND product_id = ?";
        $result = $this->db->query($check_sql, [$user_id, $product_id]);
        
        if ($result && $result->num_rows > 0) {
            // Kaydı güncelle
            $update_sql = "UPDATE user_downloads SET download_count = download_count + 1, last_download = NOW() WHERE user_id = ? AND product_id = ?";
            $this->db->query($update_sql, [$user_id, $product_id]);
        } else {
            // Yeni kayıt oluştur
            $insert_sql = "INSERT INTO user_downloads (user_id, product_id, last_download) VALUES (?, ?, NOW())";
            $this->db->query($insert_sql, [$user_id, $product_id]);
        }
    }
    
    public function getDownloadStats($user_id) {
        $sql = "SELECT COUNT(*) as total_downloads FROM user_downloads WHERE user_id = ?";
        $result = $this->db->query($sql, [$user_id]);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc()['total_downloads'];
        }
        
        return 0;
    }
    
    public function createSupportTicket($user_id, $subject, $message, $priority = 'medium') {
        $sql = "INSERT INTO support_tickets (user_id, subject, message, priority) VALUES (?, ?, ?, ?)";
        $result = $this->db->query($sql, [$user_id, $subject, $message, $priority]);
        
        return $result ? $this->db->getLastInsertId() : false;
    }
    
    public function getUserTickets($user_id) {
        $sql = "SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC";
        $result = $this->db->query($sql, [$user_id]);
        
        $tickets = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $tickets[] = $row;
            }
        }
        
        return $tickets;
    }
    
    public function getTicket($ticket_id, $user_id = null) {
        $sql = "SELECT * FROM support_tickets WHERE id = ?";
        $params = [$ticket_id];
        
        if ($user_id) {
            $sql .= " AND user_id = ?";
            $params[] = $user_id;
        }
        
        $result = $this->db->query($sql, $params);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return null;
    }
    
    public function addTicketReply($ticket_id, $user_id, $message, $is_admin = false) {
        $sql = "INSERT INTO ticket_replies (ticket_id, user_id, message, is_admin) VALUES (?, ?, ?, ?)";
        $result = $this->db->query($sql, [$ticket_id, $user_id, $message, $is_admin]);
        
        if ($result) {
            // Ticket'ı güncelle
            $update_sql = "UPDATE support_tickets SET updated_at = NOW() WHERE id = ?";
            $this->db->query($update_sql, [$ticket_id]);
            
            return true;
        }
        
        return false;
    }
    
    public function getTicketReplies($ticket_id) {
        $sql = "SELECT tr.*, u.name, u.email 
                FROM ticket_replies tr 
                JOIN users u ON tr.user_id = u.id 
                WHERE tr.ticket_id = ? 
                ORDER BY tr.created_at ASC";
        $result = $this->db->query($sql, [$ticket_id]);
        
        $replies = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $replies[] = $row;
            }
        }
        
        return $replies;
    }
    
    public function updateTicketStatus($ticket_id, $status, $user_id = null) {
        $sql = "UPDATE support_tickets SET status = ?, updated_at = NOW() WHERE id = ?";
        $params = [$status, $ticket_id];
        
        if ($user_id) {
            $sql .= " AND user_id = ?";
            $params[] = $user_id;
        }
        
        return $this->db->query($sql, $params);
    }
    
    private function sendVerificationEmail($email, $token) {
        // Gerçek uygulamada email gönderimi yapılır
        $verification_link = "http://yourdomain.com/verify.php?token=" . $token;
        
        // Simülasyon - log dosyasına yaz
        error_log("Verification email sent to: " . $email . " with token: " . $token);
        
        return true;
    }
    
    public function verifyEmail($token) {
        $sql = "UPDATE users SET email_verified = TRUE, verification_token = NULL WHERE verification_token = ?";
        $result = $this->db->query($sql, [$token]);
        
        return $result && $this->db->conn->affected_rows > 0;
    }
    
    public function requestPasswordReset($email) {
        $user = $this->getUserByEmail($email);
        if (!$user) {
            return ['success' => false, 'message' => 'email_not_found'];
        }
        
        $reset_token = $this->security->generateToken();
        $sql = "UPDATE users SET reset_token = ? WHERE email = ?";
        $result = $this->db->query($sql, [$reset_token, $email]);
        
        if ($result) {
            $this->sendPasswordResetEmail($email, $reset_token);
            return ['success' => true, 'message' => 'reset_email_sent'];
        }
        
        return ['success' => false, 'message' => 'unknown_error'];
    }
    
    public function resetPassword($token, $new_password) {
        if (strlen($new_password) < 6) {
            return ['success' => false, 'message' => 'password_requirements'];
        }
        
        $user = $this->getUserByResetToken($token);
        if (!$user) {
            return ['success' => false, 'message' => 'invalid_token'];
        }
        
        $new_password_hash = $this->security->hashPassword($new_password);
        $sql = "UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?";
        $result = $this->db->query($sql, [$new_password_hash, $token]);
        
        if ($result) {
            return ['success' => true, 'message' => 'password_reset_success'];
        }
        
        return ['success' => false, 'message' => 'unknown_error'];
    }
    
    private function getUserByResetToken($token) {
        $sql = "SELECT * FROM users WHERE reset_token = ?";
        $result = $this->db->query($sql, [$token]);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return null;
    }
    
    private function sendPasswordResetEmail($email, $token) {
        $reset_link = "http://yourdomain.com/reset-password.php?token=" . $token;
        
        // Simülasyon - log dosyasına yaz
        error_log("Password reset email sent to: " . $email . " with token: " . $token);
        
        return true;
    }
}
?>