<?php
class LanguageManager {
    private $available_languages = ['tr', 'en', 'de'];
    private $default_language = 'tr';
    private $current_language;
    
    public function __construct() {
        if (isset($_GET['lang']) && in_array($_GET['lang'], $this->available_languages)) {
            $this->current_language = $_GET['lang'];
            $_SESSION['lang'] = $this->current_language;
        } elseif (isset($_SESSION['lang']) && in_array($_SESSION['lang'], $this->available_languages)) {
            $this->current_language = $_SESSION['lang'];
        } else {
            $browser_lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
            $this->current_language = in_array($browser_lang, $this->available_languages) ? $browser_lang : $this->default_language;
            $_SESSION['lang'] = $this->current_language;
        }
    }
    
    public function getCurrentLanguage() {
        return $this->current_language;
    }
    
    public function getAvailableLanguages() {
        return $this->available_languages;
    }
    
    public function getLanguageName($code) {
        $names = [
            'tr' => 'Türkçe',
            'en' => 'English',
            'de' => 'Deutsch'
        ];
        return $names[$code] ?? $code;
    }
    
    public function setLanguage($language) {
        if (in_array($language, $this->available_languages)) {
            $this->current_language = $language;
            $_SESSION['lang'] = $language;
            return true;
        }
        return false;
    }
}
?>