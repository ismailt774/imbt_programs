<?php
class ProductManager {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function getProducts($active_only = true) {
        $sql = "SELECT * FROM products";
        if ($active_only) {
            $sql .= " WHERE is_active = TRUE";
        }
        $sql .= " ORDER BY price ASC";
        
        $result = $this->db->query($sql);
        
        $products = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        
        return $products;
    }
    
    public function getProduct($product_id) {
        $sql = "SELECT * FROM products WHERE id = ?";
        $result = $this->db->query($sql, [$product_id]);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return null;
    }
    
    public function getProductsByPlan($plan) {
        $sql = "SELECT * FROM products WHERE required_plan = ? AND is_active = TRUE ORDER BY price ASC";
        $result = $this->db->query($sql, [$plan]);
        
        $products = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        
        return $products;
    }
    
    public function getPopularProducts($limit = 3) {
        $sql = "
            SELECT p.*, COUNT(ud.id) as download_count 
            FROM products p 
            LEFT JOIN user_downloads ud ON p.id = ud.product_id 
            WHERE p.is_active = TRUE 
            GROUP BY p.id 
            ORDER BY download_count DESC 
            LIMIT ?
        ";
        
        $result = $this->db->query($sql, [$limit]);
        
        $products = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        
        return $products;
    }
    
    public function searchProducts($query) {
        $search_term = "%" . $this->db->escape($query) . "%";
        $sql = "SELECT * FROM products WHERE (name LIKE ? OR description LIKE ?) AND is_active = TRUE ORDER BY price ASC";
        $result = $this->db->query($sql, [$search_term, $search_term]);
        
        $products = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        
        return $products;
    }
    
    public function addProduct($product_data) {
        $sql = "INSERT INTO products (name, description, price, required_plan, image_url, download_url, version, file_size) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $result = $this->db->query($sql, [
            $product_data['name'],
            $product_data['description'],
            $product_data['price'],
            $product_data['required_plan'],
            $product_data['image_url'] ?? '',
            $product_data['download_url'] ?? '',
            $product_data['version'] ?? '1.0.0',
            $product_data['file_size'] ?? '0 MB'
        ]);
        
        return $result ? $this->db->getLastInsertId() : false;
    }
    
    public function updateProduct($product_id, $product_data) {
        $sql = "UPDATE products SET name = ?, description = ?, price = ?, required_plan = ?, image_url = ?, download_url = ?, version = ?, file_size = ?, is_active = ? WHERE id = ?";
        
        return $this->db->query($sql, [
            $product_data['name'],
            $product_data['description'],
            $product_data['price'],
            $product_data['required_plan'],
            $product_data['image_url'],
            $product_data['download_url'],
            $product_data['version'],
            $product_data['file_size'],
            $product_data['is_active'],
            $product_id
        ]);
    }
    
    public function deleteProduct($product_id) {
        $sql = "DELETE FROM products WHERE id = ?";
        return $this->db->query($sql, [$product_id]);
    }
    
    public function getUserDownloadStats($user_id) {
        $sql = "SELECT COUNT(*) as total_downloads FROM user_downloads WHERE user_id = ?";
        $result = $this->db->query($sql, [$user_id]);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc()['total_downloads'];
        }
        
        return 0;
    }
    
    public function getUserDownloads($user_id) {
        $sql = "SELECT ud.*, p.name as product_name, p.version, p.file_size 
                FROM user_downloads ud 
                JOIN products p ON ud.product_id = p.id 
                WHERE ud.user_id = ? 
                ORDER BY ud.last_download DESC";
        
        $result = $this->db->query($sql, [$user_id]);
        
        $downloads = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $downloads[] = $row;
            }
        }
        
        return $downloads;
    }
    
    public function recordDownload($user_id, $product_id) {
        // Önce kayıt var mı kontrol et
        $check_sql = "SELECT * FROM user_downloads WHERE user_id = ? AND product_id = ?";
        $result = $this->db->query($check_sql, [$user_id, $product_id]);
        
        if ($result && $result->num_rows > 0) {
            // Kaydı güncelle
            $update_sql = "UPDATE user_downloads SET download_count = download_count + 1, last_download = NOW() WHERE user_id = ? AND product_id = ?";
            return $this->db->query($update_sql, [$user_id, $product_id]);
        } else {
            // Yeni kayıt oluştur
            $insert_sql = "INSERT INTO user_downloads (user_id, product_id, last_download) VALUES (?, ?, NOW())";
            return $this->db->query($insert_sql, [$user_id, $product_id]);
        }
    }
    
    public function canAccessProduct($user_plan, $required_plan) {
        $plan_hierarchy = [
            'personal' => 1,
            'lite' => 2,
            'pro' => 3,
            'pro_max' => 4,
            'ultimate' => 5
        ];
        
        return ($plan_hierarchy[$user_plan] ?? 0) >= ($plan_hierarchy[$required_plan] ?? 0);
    }
    
    public function getProductStats() {
        $stats = [];
        
        // Toplam ürün sayısı
        $result = $this->db->query("SELECT COUNT(*) as total FROM products");
        $stats['total_products'] = $result->fetch_assoc()['total'];
        
        // Aktif ürün sayısı
        $result = $this->db->query("SELECT COUNT(*) as active FROM products WHERE is_active = TRUE");
        $stats['active_products'] = $result->fetch_assoc()['active'];
        
        // Plan bazlı ürün sayıları
        $plans = ['personal', 'lite', 'pro', 'pro_max', 'ultimate'];
        foreach ($plans as $plan) {
            $result = $this->db->query("SELECT COUNT(*) as count FROM products WHERE required_plan = ?", [$plan]);
            $stats['products_by_plan'][$plan] = $result->fetch_assoc()['count'];
        }
        
        return $stats;
    }
}
?>