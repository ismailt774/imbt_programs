<?php
class SecurityManager {
    private $csrf_token;
    
    public function __construct() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(64));
        }
        $this->csrf_token = $_SESSION['csrf_token'];
    }
    
    public function validateCSRF($token) {
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    public function getCSRFToken() {
        return $this->csrf_token;
    }
    
    public function sanitizeInput($input) {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }
        return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
    }
    
    public function hashPassword($password) {
        return password_hash($password, PASSWORD_DEFAULT);
    }
    
    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    public function generateToken($length = 32) {
        return bin2hex(random_bytes($length));
    }
    
    public function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    public function sanitizeFileName($filename) {
        $filename = preg_replace('/[^a-zA-Z0-9\.\_\-]/', '', $filename);
        return substr($filename, 0, 255);
    }
    
    public function checkBruteForce($user_id, $max_attempts = 5, $time_window = 900) {
        $now = time();
        $valid_attempts = $now - $time_window;
        
        // Burada login attempt tablosu olmalı, basit implementasyon
        if (isset($_SESSION['login_attempts'])) {
            if ($_SESSION['login_attempts'] >= $max_attempts && 
                isset($_SESSION['last_attempt_time']) && 
                ($now - $_SESSION['last_attempt_time']) < $time_window) {
                return true;
            }
        }
        return false;
    }
    
    public function recordLoginAttempt() {
        if (!isset($_SESSION['login_attempts'])) {
            $_SESSION['login_attempts'] = 1;
        } else {
            $_SESSION['login_attempts']++;
        }
        $_SESSION['last_attempt_time'] = time();
    }
    
    public function clearLoginAttempts() {
        unset($_SESSION['login_attempts']);
        unset($_SESSION['last_attempt_time']);
    }
}
?>