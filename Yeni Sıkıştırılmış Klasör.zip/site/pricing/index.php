<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/ProductManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$productManager = new ProductManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

$plans = [
    'personal' => [
        'name' => 'personal_plan',
        'price' => 0,
        'period' => 'month',
        'users' => 1,
        'features' => ['basic_support', 'access_personal_products'],
        'description' => 'personal_desc',
        'recommended' => false
    ],
    'lite' => [
        'name' => 'lite_plan',
        'price' => 29,
        'period' => 'month',
        'users' => 5,
        'features' => ['basic_support', 'advanced_analytics', 'access_lite_products'],
        'description' => 'lite_desc',
        'recommended' => false
    ],
    'pro' => [
        'name' => 'pro_plan',
        'price' => 79,
        'period' => 'month',
        'users' => 10,
        'features' => ['premium_support', 'advanced_analytics', 'custom_integrations', 'access_pro_products'],
        'description' => 'pro_desc',
        'recommended' => true
    ],
    'pro_max' => [
        'name' => 'pro_max_plan',
        'price' => 149,
        'period' => 'month',
        'users' => 25,
        'features' => ['premium_support', 'advanced_analytics', 'custom_integrations', 'dedicated_account_manager', 'ai_powered_insights', 'access_pro_max_products'],
        'description' => 'pro_max_desc',
        'recommended' => false
    ],
    'ultimate' => [
        'name' => 'ultimate_plan',
        'price' => 299,
        'period' => 'month',
        'users' => 999,
        'features' => ['premium_support', 'advanced_analytics', 'custom_integrations', 'dedicated_account_manager', 'ai_powered_insights', 'white_label_solution', 'enterprise_security', 'unlimited_users', 'access_all_products'],
        'description' => 'ultimate_desc',
        'recommended' => false
    ]
];

$current_user = $userManager->getUser();
$current_plan = $current_user ? $current_user['plan'] : 'personal';

// Plan yükseltme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $userManager->isLoggedIn()) {
    $new_plan = $_POST['plan'] ?? '';
    
    if (array_key_exists($new_plan, $plans)) {
        if ($userManager->upgradePlan($current_user['id'], $new_plan)) {
            $_SESSION['success'] = $translator->translate('plan_upgraded');
            header('Location: index.php');
            exit;
        } else {
            $error = $translator->translate('plan_upgrade_error');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('pricing'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #0f172a;
            --secondary-dark: #1e293b;
            --accent-blue: #3b82f6;
            --accent-purple: #8b5cf6;
            --accent-cyan: #06b6d4;
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, var(--primary-dark) 0%, #020617 100%);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .section-title {
            position: relative;
            margin-bottom: 3rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .pricing-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
            height: 100%;
            position: relative;
        }
        
        .pricing-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(59, 130, 246, 0.3);
        }
        
        .pricing-card.recommended {
            border-color: var(--accent-blue);
            transform: scale(1.05);
        }
        
        .pricing-card.recommended::before {
            content: '<?php echo $translator->translate('recommended'); ?>';
            position: absolute;
            top: -10px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--accent-blue);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .plan-price {
            font-size: 3rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .btn-gradient {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            color: white;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-outline-gradient {
            border: 2px solid transparent;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-dark)) padding-box,
                        linear-gradient(135deg, var(--accent-blue), var(--accent-purple)) border-box;
            color: white;
            padding: 10px 30px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-outline-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .feature-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .feature-list li {
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
        }
        
        .feature-list li i {
            color: #4ade80;
            margin-right: 10px;
            font-size: 0.9rem;
        }
        
        .feature-list li.disabled {
            color: var(--text-secondary);
        }
        
        .feature-list li.disabled i {
            color: var(--text-secondary);
        }
        
        .plan-indicator {
            display: inline-block;
            padding: 5px 15px;
            background: rgba(59, 130, 246, 0.2);
            color: var(--accent-blue);
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        
        .message.success {
            background: rgba(34, 197, 94, 0.1);
            color: #4ade80;
            border-left-color: #4ade80;
        }
        
        .message.error {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border-left-color: #f87171;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <?php include '../includes/navigation.php'; ?>

    <div class="container py-5 mt-5">
        <!-- Header -->
        <div class="row mb-5">
            <div class="col-12 text-center">
                <h1 class="section-title" data-aos="fade-up"><?php echo $translator->translate('pricing'); ?></h1>
                <p class="lead text-muted" data-aos="fade-up" data-aos-delay="100">
                    <?php echo $userManager->isLoggedIn() ? 
                        sprintf($translator->translate('current_plan') . ': %s', $translator->translate($plans[$current_plan]['name'])) : 
                        $translator->translate('choose_plan'); ?>
                </p>
            </div>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="row justify-content-center mb-4">
                <div class="col-lg-8">
                    <div class="message success">
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="row justify-content-center mb-4">
                <div class="col-lg-8">
                    <div class="message error">
                        <?php echo $error; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Pricing Cards -->
        <div class="row g-4 justify-content-center">
            <?php foreach ($plans as $plan_key => $plan): ?>
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo $plan['recommended'] ? '200' : '100'; ?>">
                    <div class="pricing-card <?php echo $plan['recommended'] ? 'recommended' : ''; ?>">
                        <h4 class="text-center mb-3"><?php echo $translator->translate($plan['name']); ?></h4>
                        <p class="text-center text-muted mb-4"><?php echo $translator->translate($plan['description']); ?></p>
                        
                        <div class="text-center mb-4">
                            <span class="plan-price">$<?php echo $plan['price']; ?></span>
                            <span class="text-muted">/<?php echo $translator->translate($plan['period']); ?></span>
                        </div>
                        
                        <p class="text-center text-muted mb-4">
                            <i class="fas fa-users me-2"></i><?php echo $plan['users']; ?> <?php echo $translator->translate('user'); ?>
                        </p>
                        
                        <ul class="feature-list mb-4">
                            <?php foreach ($plan['features'] as $feature): ?>
                                <li>
                                    <i class="fas fa-check"></i> <?php echo $translator->translate($feature); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        
                        <div class="text-center mt-auto">
                            <?php if ($userManager->isLoggedIn()): ?>
                                <?php if ($current_plan === $plan_key): ?>
                                    <button class="btn btn-outline-gradient" disabled>
                                        <i class="fas fa-check me-2"></i><?php echo $translator->translate('current'); ?>
                                    </button>
                                <?php else: ?>
                                    <form method="POST" class="d-inline w-100">
                                        <input type="hidden" name="plan" value="<?php echo $plan_key; ?>">
                                        <button type="submit" class="btn btn-gradient">
                                            <?php echo $translator->translate('choose_plan'); ?>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="../auth/register.php" class="btn btn-gradient">
                                    <?php echo $translator->translate('choose_plan'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Özellikler Karşılaştırması -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="text-center mb-5">
                    <h3 class="section-title"><?php echo $translator->translate('feature_comparison'); ?></h3>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th><?php echo $translator->translate('feature'); ?></th>
                                <?php foreach ($plans as $plan_key => $plan): ?>
                                    <th class="text-center"><?php echo $translator->translate($plan['name']); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo $translator->translate('basic_support'); ?></td>
                                <?php foreach ($plans as $plan_key => $plan): ?>
                                    <td class="text-center">
                                        <?php if (in_array('basic_support', $plan['features'])): ?>
                                            <i class="fas fa-check text-success"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times text-danger"></i>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td><?php echo $translator->translate('premium_support'); ?></td>
                                <?php foreach ($plans as $plan_key => $plan): ?>
                                    <td class="text-center">
                                        <?php if (in_array('premium_support', $plan['features'])): ?>
                                            <i class="fas fa-check text-success"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times text-danger"></i>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td><?php echo $translator->translate('advanced_analytics'); ?></td>
                                <?php foreach ($plans as $plan_key => $plan): ?>
                                    <td class="text-center">
                                        <?php if (in_array('advanced_analytics', $plan['features'])): ?>
                                            <i class="fas fa-check text-success"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times text-danger"></i>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td><?php echo $translator->translate('custom_integrations'); ?></td>
                                <?php foreach ($plans as $plan_key => $plan): ?>
                                    <td class="text-center">
                                        <?php if (in_array('custom_integrations', $plan['features'])): ?>
                                            <i class="fas fa-check text-success"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times text-danger"></i>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td><?php echo $translator->translate('dedicated_account_manager'); ?></td>
                                <?php foreach ($plans as $plan_key => $plan): ?>
                                    <td class="text-center">
                                        <?php if (in_array('dedicated_account_manager', $plan['features'])): ?>
                                            <i class="fas fa-check text-success"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times text-danger"></i>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // AOS Initialization
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });
    </script>
</body>
</html>