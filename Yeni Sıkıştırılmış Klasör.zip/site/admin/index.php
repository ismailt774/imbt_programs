<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/ProductManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$productManager = new ProductManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

// Admin kontrolü - basit implementasyon
if (!$userManager->isLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

$user = $userManager->getUser();
// Gerçek uygulamada burada admin rol kontrolü yapılır
$is_admin = true; // Demo için

if (!$is_admin) {
    header('Location: ../dashboard/');
    exit;
}

// İstatistikleri al
$total_users = $userManager->getTotalUsers();
$total_products = $productManager->getProductStats()['total_products'];
$total_downloads = $productManager->getTotalDownloads();
$recent_tickets = $userManager->getRecentTickets(5);
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Admin Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-crown me-2"></i>
                <strong>IMBTSoft Admin</strong>
            </a>
            
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-shield me-1"></i>
                        <?php echo htmlspecialchars($user['name']); ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../dashboard/">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../auth/logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Çıkış
                        </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Admin Sidebar -->
            <div class="col-lg-2 bg-dark text-white vh-100 p-0">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-tachometer-alt me-2"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>
                                Kullanıcılar
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">
                                <i class="fas fa-box me-2"></i>
                                Ürünler
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="tickets.php">
                                <i class="fas fa-ticket-alt me-2"></i>
                                Destek Talepleri
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="orders.php">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Siparişler
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog me-2"></i>
                                Ayarlar
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Admin Dashboard</h2>
                    <div class="btn-group">
                        <button class="btn btn-outline-primary">
                            <i class="fas fa-download me-2"></i>Rapor İndir
                        </button>
                        <button class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Yeni Ekle
                        </button>
                    </div>
                </div>

                <!-- Stats Grid -->
                <div class="row g-4 mb-5">
                    <div class="col-xl-3 col-md-6">
                        <div class="glass-card text-center">
                            <div class="stats-number"><?php echo $total_users; ?></div>
                            <p class="text-muted mb-0">Toplam Kullanıcı</p>
                            <small class="text-success">
                                <i class="fas fa-arrow-up me-1"></i>12% artış
                            </small>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="glass-card text-center">
                            <div class="stats-number"><?php echo $total_products; ?></div>
                            <p class="text-muted mb-0">Toplam Ürün</p>
                            <small class="text-success">
                                <i class="fas fa-arrow-up me-1"></i>5% artış
                            </small>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="glass-card text-center">
                            <div class="stats-number"><?php echo $total_downloads; ?></div>
                            <p class="text-muted mb-0">Toplam İndirme</p>
                            <small class="text-success">
                                <i class="fas fa-arrow-up me-1"></i>23% artış
                            </small>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="glass-card text-center">
                            <div class="stats-number">$45,678</div>
                            <p class="text-muted mb-0">Toplam Gelir</p>
                            <small class="text-success">
                                <i class="fas fa-arrow-up me-1"></i>8% artış
                            </small>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="glass-card">
                            <h4 class="mb-4">Son Aktivite</h4>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover">
                                    <thead>
                                        <tr>
                                            <th>Kullanıcı</th>
                                            <th>Aktivite</th>
                                            <th>Tarih</th>
                                            <th>Durum</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Ahmet Yılmaz</td>
                                            <td>Pro Plan satın aldı</td>
                                            <td>2 dakika önce</td>
                                            <td><span class="badge bg-success">Tamamlandı</span></td>
                                        </tr>
                                        <tr>
                                            <td>Ayşe Demir</td>
                                            <td>AI Analytics indirdi</td>
                                            <td>5 dakika önce</td>
                                            <td><span class="badge bg-success">Tamamlandı</span></td>
                                        </tr>
                                        <tr>
                                            <td>Mehmet Kaya</td>
                                            <td>Destek talebi oluşturdu</td>
                                            <td>10 dakika önce</td>
                                            <td><span class="badge bg-warning">Beklemede</span></td>
                                        </tr>
                                        <tr>
                                            <td>Zeynep Şahin</td>
                                            <td>Ultimate Plan'a yükseldi</td>
                                            <td>15 dakika önce</td>
                                            <td><span class="badge bg-success">Tamamlandı</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="glass-card">
                            <h4 class="mb-4">Sistem Durumu</h4>
                            <div class="system-status">
                                <div class="status-item d-flex justify-content-between align-items-center mb-3">
                                    <span>Veritabanı</span>
                                    <span class="badge bg-success">Aktif</span>
                                </div>
                                <div class="status-item d-flex justify-content-between align-items-center mb-3">
                                    <span>API Servisleri</span>
                                    <span class="badge bg-success">Aktif</span>
                                </div>
                                <div class="status-item d-flex justify-content-between align-items-center mb-3">
                                    <span>Email Servisi</span>
                                    <span class="badge bg-warning">Bakımda</span>
                                </div>
                                <div class="status-item d-flex justify-content-between align-items-center mb-3">
                                    <span>CDN</span>
                                    <span class="badge bg-success">Aktif</span>
                                </div>
                            </div>
                        </div>

                        <div class="glass-card mt-4">
                            <h4 class="mb-4">Hızlı İşlemler</h4>
                            <div class="d-grid gap-2">
                                <button class="btn btn-outline-primary">
                                    <i class="fas fa-user-plus me-2"></i>Kullanıcı Ekle
                                </button>
                                <button class="btn btn-outline-primary">
                                    <i class="fas fa-box me-2"></i>Ürün Ekle
                                </button>
                                <button class="btn btn-outline-primary">
                                    <i class="fas fa-cog me-2"></i>Sistem Ayarları
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="../assets/js/dashboard.js"></script>
    
    <script>
        // Admin-specific JavaScript
        $(document).ready(function() {
            $('.table').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'
                }
            });
        });
    </script>
</body>
</html>