<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/ProductManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$productManager = new ProductManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

$plans = [
    'personal' => ['name' => 'personal_plan', 'price' => 0],
    'lite' => ['name' => 'lite_plan', 'price' => 29],
    'pro' => ['name' => 'pro_plan', 'price' => 79],
    'pro_max' => ['name' => 'pro_max_plan', 'price' => 149],
    'ultimate' => ['name' => 'ultimate_plan', 'price' => 299]
];

// Arama işlemi
$search_query = '';
$products = [];
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_query = $_GET['search'];
    $products = $productManager->searchProducts($search_query);
} else {
    $products = $productManager->getProducts();
}

$popular_products = $productManager->getPopularProducts(3);
$current_user = $userManager->getUser();
$current_plan = $current_user ? $current_user['plan'] : 'personal';
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('products'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #0f172a;
            --secondary-dark: #1e293b;
            --accent-blue: #3b82f6;
            --accent-purple: #8b5cf6;
            --accent-cyan: #06b6d4;
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, var(--primary-dark) 0%, #020617 100%);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .glass-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
        }
        
        .glass-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(59, 130, 246, 0.3);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }
        
        .section-title {
            position: relative;
            margin-bottom: 3rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .gradient-text {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple), var(--accent-cyan));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .btn-gradient {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            color: white;
            transition: all 0.3s ease;
        }
        
        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .product-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            border-color: rgba(59, 130, 246, 0.3);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
        }
        
        .product-image {
            height: 200px;
            background-size: cover;
            background-position: center;
            position: relative;
        }
        
        .plan-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(59, 130, 246, 0.2);
            color: var(--accent-blue);
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .product-meta {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }
        
        .access-denied {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 10px;
            padding: 1rem;
            text-align: center;
            margin-top: 1rem;
        }
        
        .search-box {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 50px;
            padding: 0.5rem 1.5rem;
            color: white;
        }
        
        .search-box:focus {
            background: rgba(255, 255, 255, 0.1);
            border-color: var(--accent-blue);
            color: white;
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        
        .plan-indicator {
            display: inline-block;
            padding: 5px 15px;
            background: rgba(59, 130, 246, 0.2);
            color: var(--accent-blue);
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .floating-element {
            animation: float 6s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <?php include '../includes/navigation.php'; ?>

    <div class="container py-5 mt-5">
        <!-- Header -->
        <div class="row mb-5">
            <div class="col-12 text-center">
                <h1 class="section-title" data-aos="fade-up"><?php echo $translator->translate('all_products'); ?></h1>
                <p class="lead text-muted" data-aos="fade-up" data-aos-delay="100">
                    <?php echo $translator->translate('discover_our_software'); ?>
                </p>
            </div>
        </div>

        <!-- Arama -->
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto">
                <form method="GET" class="d-flex gap-2">
                    <input type="text" name="search" class="form-control search-box" 
                           placeholder="<?php echo $translator->translate('search_products'); ?>" 
                           value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit" class="btn btn-gradient">
                        <i class="fas fa-search me-2"></i><?php echo $translator->translate('search'); ?>
                    </button>
                </form>
            </div>
        </div>

        <?php if (!$userManager->isLoggedIn()): ?>
            <div class="row justify-content-center mb-5">
                <div class="col-lg-8">
                    <div class="glass-card text-center" data-aos="fade-up">
                        <h4><?php echo $translator->translate('premium_products'); ?></h4>
                        <p class="text-muted mb-4"><?php echo $translator->translate('upgrade_required'); ?></p>
                        <a href="../auth/register.php" class="btn btn-gradient">
                            <?php echo $translator->translate('register'); ?>
                        </a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row mb-4">
                <div class="col-12">
                    <div class="glass-card" data-aos="fade-up">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5><?php echo $translator->translate('current_plan'); ?></h5>
                                <p class="mb-0"><?php echo $translator->translate($plans[$current_plan]['name']); ?> - $<?php echo $plans[$current_plan]['price']; ?>/month</p>
                            </div>
                            <div class="col-md-4 text-end">
                                <a href="../pricing/" class="btn btn-gradient">
                                    <?php echo $translator->translate('upgrade_now'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Popüler Ürünler -->
        <?php if (empty($search_query) && !empty($popular_products)): ?>
        <div class="row mb-5">
            <div class="col-12">
                <h4 class="mb-4" data-aos="fade-up"><?php echo $translator->translate('popular_products'); ?></h4>
            </div>
            <?php foreach ($popular_products as $product): ?>
                <div class="col-md-4 mb-4" data-aos="fade-up">
                    <div class="product-card">
                        <div class="product-image" style="background-image: url('<?php echo $product['image_url']; ?>')">
                            <span class="plan-badge"><?php echo $translator->translate($plans[$product['required_plan']]['name']); ?></span>
                        </div>
                        <div class="p-4">
                            <h5><?php echo $product['name']; ?></h5>
                            <p class="text-muted"><?php echo $product['description']; ?></p>
                            
                            <div class="product-meta">
                                <span><i class="fas fa-code-branch me-1"></i> <?php echo $translator->translate('version'); ?>: <?php echo $product['version']; ?></span>
                                <span><i class="fas fa-hdd me-1"></i> <?php echo $product['file_size']; ?></span>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="h5 mb-0">$<?php echo $product['price']; ?></span>
                                
                                <?php if ($userManager->isLoggedIn()): ?>
                                    <?php if ($userManager->canAccessProduct($current_plan, $product['required_plan'])): ?>
                                        <a href="download.php?id=<?php echo $product['id']; ?>" class="btn btn-gradient">
                                            <i class="fas fa-download me-2"></i><?php echo $translator->translate('download'); ?>
                                        </a>
                                    <?php else: ?>
                                        <div class="access-denied">
                                            <small><?php echo sprintf($translator->translate('product_access_denied'), 
                                                $translator->translate($plans[$product['required_plan']]['name']), 
                                                $translator->translate($plans[$current_plan]['name'])); ?></small>
                                            <a href="../pricing/" class="btn btn-sm btn-gradient mt-2">
                                                <?php echo $translator->translate('upgrade_now'); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="../auth/register.php" class="btn btn-outline-light">
                                        <?php echo $translator->translate('get_access'); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Tüm Ürünler -->
        <div class="row">
            <div class="col-12">
                <h4 class="mb-4" data-aos="fade-up">
                    <?php echo empty($search_query) ? $translator->translate('all_products') : $translator->translate('search_results'); ?>
                    <?php if (!empty($search_query)): ?>
                        <small class="text-muted">(<?php echo count($products); ?> <?php echo $translator->translate('products_found'); ?>)</small>
                    <?php endif; ?>
                </h4>
            </div>
            
            <?php if (empty($products)): ?>
                <div class="col-12">
                    <div class="glass-card text-center" data-aos="fade-up">
                        <h5><?php echo $translator->translate('no_products_found'); ?></h5>
                        <p class="text-muted"><?php echo $translator->translate('try_different_search'); ?></p>
                        <a href="index.php" class="btn btn-gradient"><?php echo $translator->translate('view_all_products'); ?></a>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up">
                        <div class="product-card">
                            <div class="product-image" style="background-image: url('<?php echo $product['image_url']; ?>')">
                                <span class="plan-badge"><?php echo $translator->translate($plans[$product['required_plan']]['name']); ?></span>
                            </div>
                            <div class="p-4">
                                <h5><?php echo $product['name']; ?></h5>
                                <p class="text-muted"><?php echo $product['description']; ?></p>
                                
                                <div class="product-meta">
                                    <span><i class="fas fa-code-branch me-1"></i> <?php echo $translator->translate('version'); ?>: <?php echo $product['version']; ?></span>
                                    <span><i class="fas fa-hdd me-1"></i> <?php echo $product['file_size']; ?></span>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="h5 mb-0">$<?php echo $product['price']; ?></span>
                                    
                                    <?php if ($userManager->isLoggedIn()): ?>
                                        <?php if ($userManager->canAccessProduct($current_plan, $product['required_plan'])): ?>
                                            <a href="download.php?id=<?php echo $product['id']; ?>" class="btn btn-gradient">
                                                <i class="fas fa-download me-2"></i><?php echo $translator->translate('download'); ?>
                                            </a>
                                        <?php else: ?>
                                            <div class="text-center">
                                                <small class="text-warning d-block"><?php echo $translator->translate('requires_upgrade'); ?></small>
                                                <a href="../pricing/" class="btn btn-sm btn-gradient mt-1">
                                                    <?php echo $translator->translate('upgrade_now'); ?>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="../auth/register.php" class="btn btn-outline-light">
                                            <?php echo $translator->translate('get_access'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // AOS Initialization
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });
    </script>
</body>
</html>