<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/ProductManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$productManager = new ProductManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

if (!$userManager->isLoggedIn()) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header('Location: ../auth/login.php');
    exit;
}

$product_id = $_GET['id'] ?? 0;
$product = $productManager->getProduct($product_id);
$user = $userManager->getUser();

if (!$product) {
    die($translator->translate('product_not_found'));
}

// Plan kontrolü
if (!$productManager->canAccessProduct($user['plan'], $product['required_plan'])) {
    die($translator->translate('access_denied'));
}

// İndirme kaydı oluştur
$userManager->recordDownload($user['id'], $product_id);

// Gerçek dosya indirme (demo için basit bir implementasyon)
if (!empty($product['download_url'])) {
    // Gerçek dosya indirme
    header('Location: ' . $product['download_url']);
    exit;
} else {
    // Demo amaçlı dosya oluşturma
    $filename = preg_replace('/[^a-zA-Z0-9]/', '_', $product['name']) . '.zip';
    
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($product['name']));
    
    echo "This is a demo download file for: " . $product['name'] . "\n\n";
    echo "Product: " . $product['name'] . "\n";
    echo "Version: " . $product['version'] . "\n";
    echo "Description: " . $product['description'] . "\n";
    echo "File Size: " . $product['file_size'] . "\n";
    echo "Downloaded on: " . date('Y-m-d H:i:s') . "\n";
    echo "Downloaded by: " . $user['name'] . " (" . $user['email'] . ")\n\n";
    echo "In a real application, this would be the actual software file.";
    
    exit;
}
?>