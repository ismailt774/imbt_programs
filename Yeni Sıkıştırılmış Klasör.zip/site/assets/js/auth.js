// IMBTSoft - Auth JavaScript Dosyası

document.addEventListener('DOMContentLoaded', function() {
    initAuthForms();
    initPasswordToggle();
    initRememberMe();
    initSessionTimeout();
    initSocialAuth();
});

// Auth form initializations
function initAuthForms() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    const resetPasswordForm = document.getElementById('resetPasswordForm');

    if (loginForm) initLoginForm(loginForm);
    if (registerForm) initRegisterForm(registerForm);
    if (forgotPasswordForm) initForgotPasswordForm(forgotPasswordForm);
    if (resetPasswordForm) initResetPasswordForm(resetPasswordForm);
}

// Login form handling
function initLoginForm(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateLoginForm(this)) {
            submitLoginForm(this);
        }
    });

    // Real-time validation
    const emailInput = form.querySelector('input[type="email"]');
    const passwordInput = form.querySelector('input[type="password"]');

    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            validateEmail(this.value, this);
        });
    }

    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            validatePassword(this.value, this);
        });
    }
}

// Register form handling
function initRegisterForm(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateRegisterForm(this)) {
            submitRegisterForm(this);
        }
    });

    // Real-time validation for all inputs
    const inputs = form.querySelectorAll('input[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
    });

    // Password confirmation match
    const passwordInput = form.querySelector('input[name="password"]');
    const confirmPasswordInput = form.querySelector('input[name="confirm_password"]');
    
    if (passwordInput && confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            validatePasswordMatch(passwordInput.value, this.value, this);
        });
    }
}

// Forgot password form
function initForgotPasswordForm(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateEmailForm(this)) {
            submitForgotPasswordForm(this);
        }
    });
}

// Reset password form
function initResetPasswordForm(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateResetPasswordForm(this)) {
            submitResetPasswordForm(this);
        }
    });

    // Password strength and match validation
    const newPasswordInput = form.querySelector('input[name="new_password"]');
    const confirmPasswordInput = form.querySelector('input[name="confirm_password"]');
    
    if (newPasswordInput) {
        newPasswordInput.addEventListener('input', function() {
            validatePasswordStrength(this.value, this);
        });
    }
    
    if (newPasswordInput && confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            validatePasswordMatch(newPasswordInput.value, this.value, this);
        });
    }
}

// Form validation functions
function validateLoginForm(form) {
    const email = form.querySelector('input[type="email"]').value;
    const password = form.querySelector('input[type="password"]').value;
    let isValid = true;

    if (!validateEmail(email)) {
        showFieldError(form.querySelector('input[type="email"]'), 'Geçerli bir email adresi giriniz.');
        isValid = false;
    }

    if (!password) {
        showFieldError(form.querySelector('input[type="password"]'), 'Şifre gereklidir.');
        isValid = false;
    }

    return isValid;
}

function validateRegisterForm(form) {
    const fields = [
        { name: 'name', type: 'text', required: true },
        { name: 'email', type: 'email', required: true },
        { name: 'password', type: 'password', required: true },
        { name: 'confirm_password', type: 'password', required: true }
    ];

    let isValid = true;

    fields.forEach(field => {
        const input = form.querySelector(`input[name="${field.name}"]`);
        if (input && !validateField(input)) {
            isValid = false;
        }
    });

    // Check password match
    const password = form.querySelector('input[name="password"]').value;
    const confirmPassword = form.querySelector('input[name="confirm_password"]').value;
    
    if (password !== confirmPassword) {
        showFieldError(form.querySelector('input[name="confirm_password"]'), 'Şifreler eşleşmiyor.');
        isValid = false;
    }

    return isValid;
}

function validateEmailForm(form) {
    const email = form.querySelector('input[type="email"]').value;
    return validateEmail(email);
}

function validateResetPasswordForm(form) {
    const newPassword = form.querySelector('input[name="new_password"]').value;
    const confirmPassword = form.querySelector('input[name="confirm_password"]').value;
    let isValid = true;

    if (!validatePasswordStrength(newPassword)) {
        showFieldError(form.querySelector('input[name="new_password"]'), 'Şifre en az 6 karakter olmalı ve güçlü olmalıdır.');
        isValid = false;
    }

    if (newPassword !== confirmPassword) {
        showFieldError(form.querySelector('input[name="confirm_password"]'), 'Şifreler eşleşmiyor.');
        isValid = false;
    }

    return isValid;
}

// Field validation
function validateField(input) {
    const value = input.value.trim();
    const type = input.type;
    const name = input.name;

    switch (type) {
        case 'email':
            return validateEmail(value, input);
        case 'password':
            return validatePassword(value, input);
        case 'text':
            return validateText(value, input, name);
        default:
            return true;
    }
}

function validateEmail(email, input = null) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = emailRegex.test(email);
    
    if (input) {
        if (email && !isValid) {
            showFieldError(input, 'Geçerli bir email adresi giriniz.');
            return false;
        } else {
            clearFieldError(input);
            return true;
        }
    }
    
    return isValid;
}

function validatePassword(password, input = null) {
    const isValid = password.length >= 6;
    
    if (input) {
        if (!isValid) {
            showFieldError(input, 'Şifre en az 6 karakter olmalıdır.');
            return false;
        } else {
            clearFieldError(input);
            return true;
        }
    }
    
    return isValid;
}

function validatePasswordStrength(password) {
    // At least 6 characters, one uppercase, one lowercase, one number
    const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/;
    return strongRegex.test(password);
}

function validatePasswordMatch(password, confirmPassword, input) {
    const isValid = password === confirmPassword;
    
    if (input) {
        if (!isValid) {
            showFieldError(input, 'Şifreler eşleşmiyor.');
            return false;
        } else {
            clearFieldError(input);
            return true;
        }
    }
    
    return isValid;
}

function validateText(text, input, fieldName) {
    const isValid = text.length >= 2;
    
    if (input) {
        if (!isValid) {
            showFieldError(input, `${fieldName} en az 2 karakter olmalıdır.`);
            return false;
        } else {
            clearFieldError(input);
            return true;
        }
    }
    
    return isValid;
}

// Field error handling
function showFieldError(input, message) {
    input.classList.add('is-invalid');
    
    let feedback = input.parentNode.querySelector('.invalid-feedback');
    if (!feedback) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        input.parentNode.appendChild(feedback);
    }
    feedback.textContent = message;
}

function clearFieldError(input) {
    input.classList.remove('is-invalid');
    input.classList.add('is-valid');
    
    const feedback = input.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
        feedback.remove();
    }
}

// Form submission functions
function submitLoginForm(form) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    
    showLoadingState(submitBtn, 'Giriş Yapılıyor...');
    
    // Simulate API call
    setTimeout(() => {
        form.submit();
    }, 1500);
}

function submitRegisterForm(form) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    
    showLoadingState(submitBtn, 'Kayıt Yapılıyor...');
    
    // Simulate API call
    setTimeout(() => {
        form.submit();
    }, 1500);
}

function submitForgotPasswordForm(form) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    
    showLoadingState(submitBtn, 'Gönderiliyor...');
    
    // Simulate API call
    setTimeout(() => {
        form.submit();
    }, 1500);
}

function submitResetPasswordForm(form) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    
    showLoadingState(submitBtn, 'Şifre Sıfırlanıyor...');
    
    // Simulate API call
    setTimeout(() => {
        form.submit();
    }, 1500);
}

// Loading state
function showLoadingState(button, text) {
    const originalText = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `<i class="fas fa-spinner fa-spin me-2"></i>${text}`;
    
    // Store original content for reset
    button.setAttribute('data-original-content', originalText);
}

function resetLoadingState(button) {
    const originalContent = button.getAttribute('data-original-content');
    if (originalContent) {
        button.innerHTML = originalContent;
    }
    button.disabled = false;
}

// Password visibility toggle
function initPasswordToggle() {
    const toggleButtons = document.querySelectorAll('.password-toggle');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentNode.querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                this.setAttribute('aria-label', 'Şifreyi gizle');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                this.setAttribute('aria-label', 'Şifreyi göster');
            }
        });
    });
}

// Remember me functionality
function initRememberMe() {
    const rememberMeCheckbox = document.querySelector('input[name="remember_me"]');
    
    if (rememberMeCheckbox) {
        // Check if remember me was previously set
        const rememberedEmail = localStorage.getItem('remembered_email');
        if (rememberedEmail) {
            const emailInput = document.querySelector('input[type="email"]');
            if (emailInput) {
                emailInput.value = rememberedEmail;
                rememberMeCheckbox.checked = true;
            }
        }

        rememberMeCheckbox.addEventListener('change', function() {
            const emailInput = document.querySelector('input[type="email"]');
            if (this.checked && emailInput && emailInput.value) {
                localStorage.setItem('remembered_email', emailInput.value);
            } else {
                localStorage.removeItem('remembered_email');
            }
        });
    }
}

// Session timeout warning
function initSessionTimeout() {
    let timeoutWarning;
    const warningTime = 5 * 60 * 1000; // 5 minutes before timeout
    const sessionTimeout = 30 * 60 * 1000; // 30 minutes session

    function startSessionTimer() {
        clearTimeout(timeoutWarning);
        
        timeoutWarning = setTimeout(() => {
            showSessionWarning();
        }, sessionTimeout - warningTime);
    }

    function showSessionWarning() {
        const warningModal = createSessionWarningModal();
        document.body.appendChild(warningModal);
        
        const modal = new bootstrap.Modal(warningModal);
        modal.show();

        // Extend session when user interacts
        const extendBtn = warningModal.querySelector('#extendSession');
        extendBtn.addEventListener('click', function() {
            modal.hide();
            startSessionTimer();
        });

        // Logout after warning period
        setTimeout(() => {
            if (modal._isShown) {
                window.location.href = 'logout.php?reason=timeout';
            }
        }, warningTime);
    }

    // Reset timer on user activity
    const events = ['mousemove', 'keypress', 'scroll', 'click'];
    events.forEach(event => {
        document.addEventListener(event, startSessionTimer, { passive: true });
    });

    startSessionTimer();
}

function createSessionWarningModal() {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content glass-card">
                <div class="modal-header border-0">
                    <h5 class="modal-title text-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Oturum Süresi Dolmak Üzere
                    </h5>
                </div>
                <div class="modal-body">
                    <p>Oturumunuz yakında sona erecek. Devam etmek istiyor musunuz?</p>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                    <button type="button" class="btn btn-primary" id="extendSession">
                        Oturumu Uzat
                    </button>
                </div>
            </div>
        </div>
    `;
    return modal;
}

// Social authentication (placeholder)
function initSocialAuth() {
    const socialButtons = document.querySelectorAll('.btn-social');
    
    socialButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const provider = this.getAttribute('data-provider');
            initiateSocialLogin(provider);
        });
    });
}

function initiateSocialLogin(provider) {
    // This would typically redirect to OAuth endpoint
    console.log(`Initiating ${provider} login`);
    
    // Show loading state
    const button = document.querySelector(`[data-provider="${provider}"]`);
    if (button) {
        showLoadingState(button, `${provider} ile Bağlanılıyor...`);
    }
    
    // Simulate social login process
    setTimeout(() => {
        alert(`${provider} login functionality would be implemented here.`);
        if (button) {
            resetLoadingState(button);
        }
    }, 2000);
}

// Auto-focus first input
function autoFocusFirstInput() {
    const firstInput = document.querySelector('form input:not([type="hidden"])');
    if (firstInput) {
        firstInput.focus();
    }
}

// Initialize when page loads
window.addEventListener('load', function() {
    autoFocusFirstInput();
});

// Export functions for global access
window.authUtils = {
    validateEmail,
    validatePassword,
    validatePasswordStrength,
    showFieldError,
    clearFieldError
};