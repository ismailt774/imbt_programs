// IMBTSoft - Dashboard JavaScript Dosyası

document.addEventListener('DOMContentLoaded', function() {
    initDashboard();
    initCharts();
    initDataTables();
    initFileUploads();
    initRealTimeUpdates();
    initDashboardSearch();
    initQuickActions();
});

// Main dashboard initialization
function initDashboard() {
    // Update dashboard stats in real-time
    updateDashboardStats();
    
    // Initialize sidebar toggle for mobile
    initSidebarToggle();
    
    // Initialize notification system
    initNotifications();
    
    // Initialize theme switcher
    initThemeSwitcher();
    
    // Initialize dashboard widgets
    initWidgets();
}

// Chart initializations
function initCharts() {
    // Revenue Chart
    initRevenueChart();
    
    // Downloads Chart
    initDownloadsChart();
    
    // User Activity Chart
    initActivityChart();
    
    // Plan Distribution Chart
    initPlanDistributionChart();
}

// Revenue Chart
function initRevenueChart() {
    const ctx = document.getElementById('revenueChart');
    if (!ctx) return;

    const revenueChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'],
            datasets: [{
                label: 'Aylık Gelir',
                data: [12000, 19000, 15000, 25000, 22000, 30000, 28000, 35000, 32000, 40000, 38000, 45000],
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#cbd5e1',
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#cbd5e1'
                    }
                }
            }
        }
    });
}

// Downloads Chart
function initDownloadsChart() {
    const ctx = document.getElementById('downloadsChart');
    if (!ctx) return;

    const downloadsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['CRM Suite', 'AI Analytics', 'Blockchain', 'Cloud Console', 'Banking Framework'],
            datasets: [{
                label: 'İndirme Sayısı',
                data: [1250, 980, 750, 1100, 850],
                backgroundColor: [
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(139, 92, 246, 0.8)',
                    'rgba(6, 182, 212, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(245, 158, 11, 0.8)'
                ],
                borderColor: [
                    '#3b82f6',
                    '#8b5cf6',
                    '#06b6d4',
                    '#10b981',
                    '#f59e0b'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#cbd5e1'
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#cbd5e1'
                    }
                }
            }
        }
    });
}

// User Activity Chart
function initActivityChart() {
    const ctx = document.getElementById('activityChart');
    if (!ctx) return;

    const activityChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Aktif', 'İdle', 'Offline'],
            datasets: [{
                data: [65, 25, 10],
                backgroundColor: [
                    '#10b981',
                    '#f59e0b',
                    '#ef4444'
                ],
                borderWidth: 2,
                borderColor: 'rgba(15, 23, 42, 0.8)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#cbd5e1',
                        padding: 20,
                        usePointStyle: true
                    }
                }
            }
        }
    });
}

// Plan Distribution Chart
function initPlanDistributionChart() {
    const ctx = document.getElementById('planDistributionChart');
    if (!ctx) return;

    const planChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Personal', 'Lite', 'Pro', 'Pro Max', 'Ultimate'],
            datasets: [{
                data: [25, 20, 30, 15, 10],
                backgroundColor: [
                    'rgba(107, 114, 128, 0.8)',
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(139, 92, 246, 0.8)',
                    'rgba(6, 182, 212, 0.8)',
                    'rgba(16, 185, 129, 0.8)'
                ],
                borderWidth: 2,
                borderColor: 'rgba(15, 23, 42, 0.8)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#cbd5e1',
                        padding: 20
                    }
                }
            }
        }
    });
}

// DataTables initialization
function initDataTables() {
    const tables = document.querySelectorAll('.data-table');
    
    tables.forEach(table => {
        if (typeof $.fn.DataTable !== 'undefined') {
            $(table).DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'
                },
                responsive: true,
                autoWidth: false,
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                     '<"row"<"col-sm-12"tr>>' +
                     '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                drawCallback: function() {
                    // Update tooltips after table redraw
                    const tooltipTriggerList = [].slice.call(this.querySelectorAll('[data-bs-toggle="tooltip"]'));
                    tooltipTriggerList.map(function(tooltipTriggerEl) {
                        return new bootstrap.Tooltip(tooltipTriggerEl);
                    });
                }
            });
        }
    });
}

// File uploads with progress
function initFileUploads() {
    const fileInputs = document.querySelectorAll('.file-upload');
    
    fileInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const files = e.target.files;
            if (files.length > 0) {
                handleFileUpload(files[0], this);
            }
        });
    });
}

function handleFileUpload(file, input) {
    const progressContainer = input.parentNode.querySelector('.upload-progress') || createProgressContainer(input);
    const progressBar = progressContainer.querySelector('.progress-bar');
    const fileName = progressContainer.querySelector('.file-name');
    
    fileName.textContent = file.name;
    progressContainer.style.display = 'block';
    
    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 10;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            showUploadSuccess(progressContainer);
        }
        
        progressBar.style.width = progress + '%';
        progressBar.setAttribute('aria-valuenow', progress);
        progressBar.textContent = Math.round(progress) + '%';
    }, 200);
}

function createProgressContainer(input) {
    const container = document.createElement('div');
    container.className = 'upload-progress mt-2';
    container.style.display = 'none';
    container.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-1">
            <small class="file-name text-muted"></small>
            <small class="progress-percent">0%</small>
        </div>
        <div class="progress" style="height: 6px;">
            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
    `;
    input.parentNode.appendChild(container);
    return container;
}

function showUploadSuccess(container) {
    const progressBar = container.querySelector('.progress-bar');
    progressBar.classList.remove('bg-primary');
    progressBar.classList.add('bg-success');
    
    setTimeout(() => {
        container.style.display = 'none';
    }, 2000);
}

// Real-time updates
function initRealTimeUpdates() {
    // Update online status
    updateOnlineStatus();
    
    // Periodic stats update
    setInterval(updateDashboardStats, 30000); // Every 30 seconds
    
    // Check for new notifications
    setInterval(checkNewNotifications, 60000); // Every minute
}

function updateOnlineStatus() {
    const statusElement = document.getElementById('onlineStatus');
    if (statusElement) {
        const isOnline = navigator.onLine;
        statusElement.textContent = isOnline ? 'Çevrimiçi' : 'Çevrimdışı';
        statusElement.className = `badge ${isOnline ? 'bg-success' : 'bg-danger'}`;
    }
}

function updateDashboardStats() {
    // Simulate API call to get updated stats
    fetch('/api/dashboard/stats')
        .then(response => response.json())
        .then(data => {
            updateStatCard('totalUsers', data.totalUsers);
            updateStatCard('totalDownloads', data.totalDownloads);
            updateStatCard('activeProjects', data.activeProjects);
            updateStatCard('revenue', data.revenue);
        })
        .catch(error => {
            console.log('Stats update failed:', error);
        });
}

function updateStatCard(elementId, newValue) {
    const element = document.getElementById(elementId);
    if (element) {
        const currentValue = parseInt(element.textContent.replace(/,/g, ''));
        if (currentValue !== newValue) {
            animateCounter(element, currentValue, newValue);
        }
    }
}

function animateCounter(element, start, end) {
    const duration = 1000;
    const range = end - start;
    const increment = range / (duration / 16);
    let current = start;

    const timer = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
            element.textContent = end.toLocaleString();
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current).toLocaleString();
        }
    }, 16);
}

// Dashboard search
function initDashboardSearch() {
    const searchInput = document.getElementById('dashboardSearch');
    if (!searchInput) return;

    const debouncedSearch = debounce(function(query) {
        performDashboardSearch(query);
    }, 300);

    searchInput.addEventListener('input', function() {
        debouncedSearch(this.value);
    });
}

function performDashboardSearch(query) {
    const searchResults = document.getElementById('searchResults');
    if (!searchResults) return;

    if (query.length < 2) {
        searchResults.style.display = 'none';
        return;
    }

    // Simulate search API call
    fetch(`/api/search?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            displaySearchResults(data, searchResults);
        })
        .catch(error => {
            console.log('Search failed:', error);
        });
}

function displaySearchResults(results, container) {
    container.innerHTML = '';
    
    if (results.length === 0) {
        container.innerHTML = '<div class="p-3 text-muted text-center">Sonuç bulunamadı</div>';
    } else {
        results.forEach(result => {
            const item = document.createElement('a');
            item.href = result.url;
            item.className = 'dropdown-item';
            item.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="${result.icon} me-2"></i>
                    <div>
                        <div class="fw-semibold">${result.title}</div>
                        <small class="text-muted">${result.description}</small>
                    </div>
                </div>
            `;
            container.appendChild(item);
        });
    }
    
    container.style.display = 'block';
}

// Quick actions
function initQuickActions() {
    const quickActionButtons = document.querySelectorAll('.quick-action');
    
    quickActionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            performQuickAction(action, this);
        });
    });
}

function performQuickAction(action, button) {
    const actions = {
        'new-ticket': () => window.location.href = 'support.php?new=ticket',
        'download-report': () => generateReport(),
        'clear-cache': () => clearCache(),
        'backup-data': () => createBackup()
    };

    if (actions[action]) {
        showLoadingState(button, 'İşleniyor...');
        setTimeout(() => {
            actions[action]();
            resetLoadingState(button);
        }, 1000);
    }
}

function generateReport() {
    // Simulate report generation
    console.log('Generating report...');
    showToast('Rapor oluşturuluyor...', 'success');
}

function clearCache() {
    // Simulate cache clearance
    console.log('Clearing cache...');
    showToast('Önbellek temizlendi', 'success');
}

function createBackup() {
    // Simulate backup creation
    console.log('Creating backup...');
    showToast('Yedekleme tamamlandı', 'success');
}

// Sidebar toggle for mobile
function initSidebarToggle() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const dashboardSidebar = document.querySelector('.dashboard-sidebar');
    
    if (sidebarToggle && dashboardSidebar) {
        sidebarToggle.addEventListener('click', function() {
            dashboardSidebar.classList.toggle('show');
        });
    }
}

// Notification system
function initNotifications() {
    const notificationBell = document.getElementById('notificationBell');
    const notificationDropdown = document.getElementById('notificationDropdown');
    
    if (notificationBell && notificationDropdown) {
        notificationBell.addEventListener('click', function(e) {
            e.preventDefault();
            markNotificationsAsRead();
        });
    }
}

function markNotificationsAsRead() {
    // Simulate marking notifications as read
    const unreadBadge = document.querySelector('.notification-badge');
    if (unreadBadge) {
        unreadBadge.style.display = 'none';
    }
}

function checkNewNotifications() {
    // Simulate checking for new notifications
    fetch('/api/notifications/unread')
        .then(response => response.json())
        .then(count => {
            updateNotificationBadge(count);
        });
}

function updateNotificationBadge(count) {
    const badge = document.querySelector('.notification-badge');
    if (badge) {
        if (count > 0) {
            badge.textContent = count > 99 ? '99+' : count;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }
}

// Theme switcher
function initThemeSwitcher() {
    const themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;

    // Check for saved theme preference or default to 'dark'
    const currentTheme = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', currentTheme);
    updateThemeToggleIcon(currentTheme);

    themeToggle.addEventListener('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeToggleIcon(newTheme);
    });
}

function updateThemeToggleIcon(theme) {
    const icon = document.querySelector('#themeToggle i');
    if (icon) {
        icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

// Widget system
function initWidgets() {
    const widgetContainers = document.querySelectorAll('.widget');
    
    widgetContainers.forEach(widget => {
        initWidget(widget);
    });
}

function initWidget(widget) {
    const refreshBtn = widget.querySelector('.widget-refresh');
    const settingsBtn = widget.querySelector('.widget-settings');
    
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            refreshWidget(widget);
        });
    }
    
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function() {
            showWidgetSettings(widget);
        });
    }
}

function refreshWidget(widget) {
    const content = widget.querySelector('.widget-content');
    const originalContent = content.innerHTML;
    
    content.innerHTML = '<div class="loading-spinner"></div>';
    
    // Simulate refresh delay
    setTimeout(() => {
        content.innerHTML = originalContent;
        showToast('Widget yenilendi', 'success');
    }, 1000);
}

function showWidgetSettings(widget) {
    // Implement widget settings modal
    console.log('Showing settings for:', widget);
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toastContainer';
        toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }

    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-bg-${type} border-0`;
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;

    toastContainer.appendChild(toast);
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast from DOM after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

// Export dashboard functions
window.dashboard = {
    refreshStats: updateDashboardStats,
    showToast: showToast,
    performSearch: performDashboardSearch
};

// Error handling for dashboard
window.addEventListener('error', function(e) {
    console.error('Dashboard error:', e.error);
    showToast('Bir hata oluştu', 'danger');
});