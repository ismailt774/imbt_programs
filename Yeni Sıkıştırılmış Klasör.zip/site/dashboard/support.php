<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/ProductManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$productManager = new ProductManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

if (!$userManager->isLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

$user = $userManager->getUser();
$user_tickets = $userManager->getUserTickets($user['id']);

$message = '';
$message_type = '';

// Yeni ticket oluşturma
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_ticket') {
    $subject = $_POST['subject'] ?? '';
    $ticket_message = $_POST['message'] ?? '';
    $priority = $_POST['priority'] ?? 'medium';
    
    if (!empty($subject) && !empty($ticket_message)) {
        $ticket_id = $userManager->createSupportTicket($user['id'], $subject, $ticket_message, $priority);
        
        if ($ticket_id) {
            $message = $translator->translate('ticket_created');
            $message_type = 'success';
            
            // Ticket listesini yenile
            $user_tickets = $userManager->getUserTickets($user['id']);
        } else {
            $message = $translator->translate('ticket_create_error');
            $message_type = 'error';
        }
    } else {
        $message = $translator->translate('fill_all_fields');
        $message_type = 'error';
    }
}

// Ticket yanıtı ekleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_reply') {
    $ticket_id = $_POST['ticket_id'] ?? 0;
    $reply_message = $_POST['reply_message'] ?? '';
    
    if (!empty($reply_message)) {
        $ticket = $userManager->getTicket($ticket_id, $user['id']);
        
        if ($ticket) {
            $success = $userManager->addTicketReply($ticket_id, $user['id'], $reply_message);
            
            if ($success) {
                $message = $translator->translate('reply_added');
                $message_type = 'success';
            } else {
                $message = $translator->translate('reply_error');
                $message_type = 'error';
            }
        } else {
            $message = $translator->translate('ticket_not_found');
            $message_type = 'error';
        }
    } else {
        $message = $translator->translate('fill_all_fields');
        $message_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('support'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-dark: #0f172a;
            --secondary-dark: #1e293b;
            --accent-blue: #3b82f6;
            --accent-purple: #8b5cf6;
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-dark) 0%, #020617 100%);
            min-height: 100vh;
            font-family: 'Inter', sans-serif;
            color: var(--text-primary);
        }
        
        .dashboard-sidebar {
            background: rgba(30, 41, 59, 0.5);
            backdrop-filter: blur(20px);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            min-height: calc(100vh - 76px);
        }
        
        .dashboard-content {
            padding: 2rem;
        }
        
        .sidebar-nav .nav-link {
            color: var(--text-secondary);
            padding: 0.75rem 1.5rem;
            border-radius: 10px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }
        
        .sidebar-nav .nav-link:hover,
        .sidebar-nav .nav-link.active {
            background: rgba(59, 130, 246, 0.2);
            color: var(--accent-blue);
        }
        
        .glass-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 2rem;
            transition: all 0.3s ease;
        }
        
        .glass-card:hover {
            border-color: rgba(59, 130, 246, 0.3);
        }
        
        .btn-gradient {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            border: none;
            padding: 10px 20px;
            border-radius: 50px;
            font-weight: 600;
            color: white;
            transition: all 0.3s ease;
        }
        
        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .ticket-card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }
        
        .ticket-card:hover {
            border-color: rgba(59, 130, 246, 0.3);
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-open { background: rgba(34, 197, 94, 0.2); color: #4ade80; }
        .status-in_progress { background: rgba(59, 130, 246, 0.2); color: var(--accent-blue); }
        .status-resolved { background: rgba(168, 85, 247, 0.2); color: #a855f7; }
        .status-closed { background: rgba(107, 114, 128, 0.2); color: #6b7280; }
        
        .priority-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .priority-low { background: rgba(34, 197, 94, 0.2); color: #4ade80; }
        .priority-medium { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
        .priority-high { background: rgba(239, 68, 68, 0.2); color: #ef4444; }
        .priority-urgent { background: rgba(185, 28, 28, 0.2); color: #b91c1c; }
        
        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        
        .message.success {
            background: rgba(34, 197, 94, 0.1);
            color: #4ade80;
            border-left-color: #4ade80;
        }
        
        .message.error {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border-left-color: #f87171;
        }
        
        .reply-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .reply-admin {
            border-left: 4px solid var(--accent-blue);
        }
        
        .reply-user {
            border-left: 4px solid var(--accent-purple);
        }
        
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            border-radius: 10px;
            padding: 12px 15px;
        }
        
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--accent-blue);
            color: white;
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <?php include '../includes/navigation.php'; ?>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-lg-2 dashboard-sidebar p-0">
                <div class="sidebar-nav p-3">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-tachometer-alt me-2"></i><?php echo $translator->translate('dashboard'); ?>
                    </a>
                    <a href="../products/" class="nav-link">
                        <i class="fas fa-box me-2"></i><?php echo $translator->translate('products'); ?>
                    </a>
                    <a href="support.php" class="nav-link active">
                        <i class="fas fa-headset me-2"></i><?php echo $translator->translate('support'); ?>
                    </a>
                    <a href="../auth/profile.php" class="nav-link">
                        <i class="fas fa-cog me-2"></i><?php echo $translator->translate('account_settings'); ?>
                    </a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-lg-10 dashboard-content">
                <?php if ($message): ?>
                    <div class="message <?php echo $message_type; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-lg-8">
                        <h2 class="mb-4"><?php echo $translator->translate('support_center'); ?></h2>
                        
                        <!-- Yeni Talep Formu -->
                        <div class="glass-card mb-5">
                            <h4 class="mb-4"><?php echo $translator->translate('create_ticket'); ?></h4>
                            <form method="POST" action="">
                                <input type="hidden" name="action" value="create_ticket">
                                
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="mb-3">
                                            <label for="subject" class="form-label"><?php echo $translator->translate('ticket_subject'); ?></label>
                                            <input type="text" class="form-control" id="subject" name="subject" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="priority" class="form-label"><?php echo $translator->translate('priority'); ?></label>
                                            <select class="form-control" id="priority" name="priority">
                                                <option value="low"><?php echo $translator->translate('low'); ?></option>
                                                <option value="medium" selected><?php echo $translator->translate('medium'); ?></option>
                                                <option value="high"><?php echo $translator->translate('high'); ?></option>
                                                <option value="urgent"><?php echo $translator->translate('urgent'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="message" class="form-label"><?php echo $translator->translate('ticket_message'); ?></label>
                                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-gradient"><?php echo $translator->translate('submit_ticket'); ?></button>
                            </form>
                        </div>
                        
                        <!-- Mevcut Talepler -->
                        <h4 class="mb-4"><?php echo $translator->translate('my_tickets'); ?></h4>
                        <?php if (empty($user_tickets)): ?>
                            <div class="glass-card text-center">
                                <p class="text-muted"><?php echo $translator->translate('no_tickets_found'); ?></p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($user_tickets as $ticket): ?>
                                <div class="ticket-card">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h5><?php echo $ticket['subject']; ?></h5>
                                        <div class="d-flex gap-2">
                                            <span class="status-badge status-<?php echo $ticket['status']; ?>">
                                                <?php echo $translator->translate($ticket['status']); ?>
                                            </span>
                                            <span class="priority-badge priority-<?php echo $ticket['priority']; ?>">
                                                <?php echo $translator->translate($ticket['priority']); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($ticket['message'])); ?></p>
                                    
                                    <!-- Ticket Yanıtları -->
                                    <?php
                                    $replies = $userManager->getTicketReplies($ticket['id']);
                                    if (!empty($replies)):
                                    ?>
                                        <div class="mt-4">
                                            <h6 class="mb-3"><?php echo $translator->translate('replies'); ?> (<?php echo count($replies); ?>)</h6>
                                            <?php foreach ($replies as $reply): ?>
                                                <div class="reply-card <?php echo $reply['is_admin'] ? 'reply-admin' : 'reply-user'; ?>">
                                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                                        <strong><?php echo $reply['name']; ?> (<?php echo $reply['is_admin'] ? $translator->translate('support_team') : $translator->translate('you'); ?>)</strong>
                                                        <small class="text-muted"><?php echo date('d.m.Y H:i', strtotime($reply['created_at'])); ?></small>
                                                    </div>
                                                    <p class="mb-0"><?php echo nl2br(htmlspecialchars($reply['message'])); ?></p>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <!-- Yanıt Formu -->
                                    <div class="mt-4">
                                        <form method="POST" action="">
                                            <input type="hidden" name="action" value="add_reply">
                                            <input type="hidden" name="ticket_id" value="<?php echo $ticket['id']; ?>">
                                            <div class="mb-3">
                                                <label for="reply_message_<?php echo $ticket['id']; ?>" class="form-label"><?php echo $translator->translate('add_reply'); ?></label>
                                                <textarea class="form-control" id="reply_message_<?php echo $ticket['id']; ?>" name="reply_message" rows="3" required></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-gradient btn-sm"><?php echo $translator->translate('send_reply'); ?></button>
                                        </form>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between text-muted mt-3">
                                        <small><?php echo $translator->translate('created_at'); ?>: <?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?></small>
                                        <small><?php echo $translator->translate('updated_at'); ?>: <?php echo date('d.m.Y H:i', strtotime($ticket['updated_at'])); ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="glass-card">
                            <h4 class="mb-4"><?php echo $translator->translate('support_resources'); ?></h4>
                            <div class="d-grid gap-2">
                                <a href="#" class="btn btn-outline-light text-start">
                                    <i class="fas fa-book me-2"></i><?php echo $translator->translate('documentation'); ?>
                                </a>
                                <a href="#" class="btn btn-outline-light text-start">
                                    <i class="fas fa-video me-2"></i><?php echo $translator->translate('video_tutorials'); ?>
                                </a>
                                <a href="#" class="btn btn-outline-light text-start">
                                    <i class="fas fa-question-circle me-2"></i><?php echo $translator->translate('faq'); ?>
                                </a>
                                <a href="#" class="btn btn-outline-light text-start">
                                    <i class="fas fa-comments me-2"></i><?php echo $translator->translate('community_forum'); ?>
                                </a>
                            </div>
                        </div>
                        
                        <div class="glass-card mt-4">
                            <h4 class="mb-4"><?php echo $translator->translate('support_contact'); ?></h4>
                            <p class="text-muted">
                                <i class="fas fa-envelope me-2"></i>support@imbtsoft.com
                            </p>
                            <p class="text-muted">
                                <i class="fas fa-phone me-2"></i>+90 (212) 123 45 67
                            </p>
                            <p class="text-muted">
                                <i class="fas fa-clock me-2"></i>24/7 <?php echo $translator->translate('support'); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>