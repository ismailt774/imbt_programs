<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/ProductManager.php';

$database = new Database();
$userManager = new UserManager($database);
$productManager = new ProductManager($database);

if (!$userManager->isLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

$user = $userManager->getUser();
$products = $productManager->getProducts();
$totalDownloads = $productManager->getUserDownloadStats($user['id']);
$userTickets = $productManager->getUserTickets($user['id']);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <?php include '../includes/navigation.php'; ?>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include '../includes/sidebar.php'; ?>

            <!-- Main Content -->
            <div class="col-lg-10 p-4">
                <h2>Hoş Geldiniz, <?php echo $user['name']; ?>!</h2>
                
                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <h5><?php echo count($products); ?></h5>
                                <p>Toplam Ürün</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <h5><?php echo $totalDownloads; ?></h5>
                                <p>Toplam İndirme</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-warning text-white">
                            <div class="card-body">
                                <h5><?php echo count($userTickets); ?></h5>
                                <p>Destek Talebi</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Products -->
                <div class="row">
                    <?php foreach ($products as $product): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $product['name']; ?></h5>
                                    <p class="card-text"><?php echo $product['description']; ?></p>
                                    <p class="text-muted">Gerekli Plan: <?php echo $product['required_plan']; ?></p>
                                    <a href="../products/download.php?id=<?php echo $product['id']; ?>" class="btn btn-primary">İndir</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>