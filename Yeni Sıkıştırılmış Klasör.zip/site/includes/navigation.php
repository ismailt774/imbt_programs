<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="../index.php">
            <i class="fas fa-code"></i> IMBTSoft
        </a>
        
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <?php if ($userManager->isLoggedIn()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard/">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../products/">Ürünler</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard/support.php">Destek</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <?php echo $user['name']; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/profile.php">Profil</a></li>
                            <li><a class="dropdown-item" href="../auth/logout.php">Çıkış</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../auth/login.php">Giriş</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../auth/register.php">Kayıt</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>