<?php
// Sidebar için gerekli class'lar zaten yüklenmiş olmalı
if (!isset($userManager) || !$userManager->isLoggedIn()) {
    return;
}

$user = $userManager->getUser();
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- Dashboard Sidebar -->
<div class="dashboard-sidebar">
    <!-- User Profile -->
    <div class="sidebar-profile text-center p-4 border-bottom">
        <div class="user-avatar mx-auto mb-3">
            <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
        </div>
        <h6 class="text-white mb-1"><?php echo htmlspecialchars($user['name']); ?></h6>
        <p class="text-muted small mb-2"><?php echo htmlspecialchars($user['email']); ?></p>
        <span class="plan-badge"><?php echo $translator->translate($user['plan'] . '_plan'); ?></span>
    </div>

    <!-- Navigation -->
    <nav class="sidebar-nav p-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a href="index.php" class="nav-link <?php echo $current_page === 'index.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt me-3"></i>
                    <?php echo $translator->translate('dashboard'); ?>
                </a>
            </li>
            <li class="nav-item">
                <a href="../products/" class="nav-link">
                    <i class="fas fa-box me-3"></i>
                    <?php echo $translator->translate('products'); ?>
                </a>
            </li>
            <li class="nav-item">
                <a href="support.php" class="nav-link <?php echo $current_page === 'support.php' ? 'active' : ''; ?>">
                    <i class="fas fa-headset me-3"></i>
                    <?php echo $translator->translate('support'); ?>
                    <?php
                    $tickets_count = count($userManager->getUserTickets($user['id']));
                    if ($tickets_count > 0): ?>
                        <span class="badge bg-primary float-end"><?php echo $tickets_count; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a href="../pricing/" class="nav-link">
                    <i class="fas fa-crown me-3"></i>
                    <?php echo $translator->translate('pricing'); ?>
                </a>
            </li>
        </ul>

        <!-- Account Section -->
        <div class="sidebar-section mt-4 pt-3 border-top">
            <h6 class="sidebar-section-title text-muted text-uppercase small mb-3">
                <?php echo $translator->translate('account'); ?>
            </h6>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="../auth/profile.php" class="nav-link <?php echo $current_page === 'profile.php' ? 'active' : ''; ?>">
                        <i class="fas fa-user me-3"></i>
                        <?php echo $translator->translate('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../auth/logout.php" class="nav-link text-danger">
                        <i class="fas fa-sign-out-alt me-3"></i>
                        <?php echo $translator->translate('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Quick Stats -->
        <div class="sidebar-stats mt-4 pt-3 border-top">
            <h6 class="sidebar-section-title text-muted text-uppercase small mb-3">
                <?php echo $translator->translate('quick_stats'); ?>
            </h6>
            <div class="stats-grid">
                <div class="stat-item text-center">
                    <div class="stat-number"><?php echo $productManager->getUserDownloadStats($user['id']); ?></div>
                    <div class="stat-label small text-muted"><?php echo $translator->translate('downloads'); ?></div>
                </div>
                <div class="stat-item text-center">
                    <div class="stat-number"><?php echo count($userManager->getUserTickets($user['id'])); ?></div>
                    <div class="stat-label small text-muted"><?php echo $translator->translate('tickets'); ?></div>
                </div>
            </div>
        </div>
    </nav>
</div>

<style>
.dashboard-sidebar {
    background: linear-gradient(135deg, var(--secondary-dark) 0%, var(--primary-dark) 100%);
    min-height: calc(100vh - 76px);
    border-right: 1px solid rgba(255, 255, 255, 0.1);
}

.sidebar-profile {
    background: rgba(255, 255, 255, 0.05);
}

.user-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 2rem;
    font-weight: 600;
    border: 3px solid rgba(255, 255, 255, 0.2);
}

.sidebar-nav .nav-link {
    color: var(--text-secondary);
    padding: 12px 15px;
    border-radius: 10px;
    margin-bottom: 5px;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
}

.sidebar-nav .nav-link:hover,
.sidebar-nav .nav-link.active {
    background: rgba(59, 130, 246, 0.2);
    color: var(--accent-blue);
    transform: translateX(5px);
}

.sidebar-nav .nav-link i {
    width: 20px;
    text-align: center;
}

.sidebar-section-title {
    font-size: 0.75rem;
    letter-spacing: 1px;
}

.sidebar-stats {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 10px;
    padding: 15px;
}

.stats-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
}

.stat-item {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 8px;
    padding: 10px;
}

.stat-number {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--accent-blue);
    line-height: 1;
}

.stat-label {
    font-size: 0.7rem;
    margin-top: 5px;
}

.plan-badge {
    display: inline-block;
    padding: 4px 12px;
    background: rgba(59, 130, 246, 0.2);
    color: var(--accent-blue);
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: 600;
}

/* Responsive */
@media (max-width: 768px) {
    .dashboard-sidebar {
        min-height: auto;
        border-right: none;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .sidebar-profile {
        padding: 1rem;
    }
    
    .user-avatar {
        width: 60px;
        height: 60px;
        font-size: 1.5rem;
    }
}
</style>