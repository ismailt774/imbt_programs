<?php
// Footer için gerekli class'lar zaten yüklenmiş olmalı
?>

<footer class="py-5 mt-5" style="background: rgba(15, 23, 42, 0.8); border-top: 1px solid rgba(255, 255, 255, 0.1);">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <h5 class="mb-3" style="background: linear-gradient(135deg, #3b82f6, #8b5cf6); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
                    <i class="fas fa-code me-2"></i> IMBTSoft
                </h5>
                <p class="text-muted"><?php echo $translator->translate('footer_description'); ?></p>
                <div class="social-links">
                    <a href="#" class="text-muted me-3"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-muted me-3"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="text-muted me-3"><i class="fab fa-linkedin"></i></a>
                    <a href="#" class="text-muted"><i class="fab fa-github"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 mb-4">
                <h6 class="text-white mb-3"><?php echo $translator->translate('company'); ?></h6>
                <ul class="list-unstyled text-muted">
                    <li class="mb-2"><a href="../about.php" class="text-muted text-decoration-none"><?php echo $translator->translate('about'); ?></a></li>
                    <li class="mb-2"><a href="../careers.php" class="text-muted text-decoration-none"><?php echo $translator->translate('careers'); ?></a></li>
                    <li class="mb-2"><a href="../contact.php" class="text-muted text-decoration-none"><?php echo $translator->translate('contact'); ?></a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 mb-4">
                <h6 class="text-white mb-3"><?php echo $translator->translate('products'); ?></h6>
                <ul class="list-unstyled text-muted">
                    <li class="mb-2"><a href="../products/" class="text-muted text-decoration-none"><?php echo $translator->translate('all_products'); ?></a></li>
                    <li class="mb-2"><a href="../pricing/" class="text-muted text-decoration-none"><?php echo $translator->translate('pricing'); ?></a></li>
                    <li class="mb-2"><a href="../features.php" class="text-muted text-decoration-none"><?php echo $translator->translate('features'); ?></a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 mb-4">
                <h6 class="text-white mb-3"><?php echo $translator->translate('support'); ?></h6>
                <ul class="list-unstyled text-muted">
                    <li class="mb-2"><a href="../help.php" class="text-muted text-decoration-none"><?php echo $translator->translate('help_center'); ?></a></li>
                    <li class="mb-2"><a href="../docs.php" class="text-muted text-decoration-none"><?php echo $translator->translate('documentation'); ?></a></li>
                    <li class="mb-2"><a href="../status.php" class="text-muted text-decoration-none"><?php echo $translator->translate('status'); ?></a></li>
                </ul>
            </div>
            <div class="col-lg-2 mb-4">
                <h6 class="text-white mb-3"><?php echo $translator->translate('contact'); ?></h6>
                <ul class="list-unstyled text-muted">
                    <li class="mb-2"><i class="fas fa-map-marker-alt me-2"></i> Maslak, İstanbul</li>
                    <li class="mb-2"><i class="fas fa-phone me-2"></i> +90 (212) 123 45 67</li>
                    <li class="mb-2"><i class="fas fa-envelope me-2"></i> info@imbtsoft.com</li>
                </ul>
            </div>
        </div>
        <hr class="bg-secondary">
        <div class="row align-items-center">
            <div class="col-md-6">
                <p class="text-muted mb-0">&copy; 2023 IMBTSoft. <?php echo $translator->translate('all_rights_reserved'); ?></p>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="../privacy.php" class="text-muted text-decoration-none me-3"><?php echo $translator->translate('privacy_policy'); ?></a>
                <a href="../terms.php" class="text-muted text-decoration-none"><?php echo $translator->translate('terms_of_service'); ?></a>
            </div>
        </div>
    </div>
</footer>