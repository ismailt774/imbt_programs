<?php
// Header için gerekli class'lar zaten yüklenmiş olmalı
?>
<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - IMBTSoft' : 'IMBTSoft | Enterprise Software Solutions'; ?></title>
    
    <!-- Meta Tags -->
    <meta name="description" content="IMBTSoft - Enterprise software solutions for businesses. CRM, analytics, security and cloud management solutions.">
    <meta name="keywords" content="software, enterprise, crm, analytics, security, cloud, management">
    <meta name="author" content="IMBTSoft">
    
    <!-- Open Graph -->
    <meta property="og:title" content="IMBTSoft | Enterprise Software Solutions">
    <meta property="og:description" content="Enterprise software solutions for businesses">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo isset($_SERVER['HTTPS']) ? 'https://' : 'http://'; echo $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="og:image" content="assets/images/og-image.jpg">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/apple-touch-icon.png">
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Additional CSS for specific pages -->
    <?php if (isset($additional_css)): ?>
        <?php foreach ($additional_css as $css): ?>
            <link href="<?php echo $css; ?>" rel="stylesheet">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body class="<?php echo isset($body_class) ? $body_class : ''; ?>">