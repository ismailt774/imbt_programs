<?php
session_start();

class Database {
    private $host = 'sql306.infinityfree.com';
    private $username = 'if0_39963970';
    private $password = 'Ismail2012!';
    private $database = 'if0_39963970_imbtsoftdb';
    public $conn;

    public function __construct() {
        try {
            $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
            
            if ($this->conn->connect_error) {
                throw new Exception("Connection failed: " . $this->conn->connect_error);
            }
            
            $this->conn->set_charset("utf8mb4");
            $this->createTables();
            
        } catch (Exception $e) {
            error_log($e->getMessage());
            $this->createFallbackFiles();
        }
    }

    private function createTables() {
        $tables = [
            "CREATE TABLE IF NOT EXISTS users (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                company VARCHAR(100),
                phone VARCHAR(20),
                company_size VARCHAR(50),
                industry VARCHAR(50),
                plan ENUM('personal', 'lite', 'pro', 'pro_max', 'ultimate') DEFAULT 'personal',
                status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
                email_verified BOOLEAN DEFAULT FALSE,
                verification_token VARCHAR(100),
                reset_token VARCHAR(100),
                last_login DATETIME,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "CREATE TABLE IF NOT EXISTS products (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                price DECIMAL(10,2) NOT NULL,
                required_plan ENUM('personal', 'lite', 'pro', 'pro_max', 'ultimate') NOT NULL,
                image_url VARCHAR(500),
                download_url VARCHAR(500),
                version VARCHAR(20),
                file_size VARCHAR(20),
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "CREATE TABLE IF NOT EXISTS orders (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                user_id INT(11) NOT NULL,
                plan_type ENUM('personal', 'lite', 'pro', 'pro_max', 'ultimate') NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
                payment_method VARCHAR(50),
                transaction_id VARCHAR(100),
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "CREATE TABLE IF NOT EXISTS user_downloads (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                user_id INT(11) NOT NULL,
                product_id INT(11) NOT NULL,
                download_count INT(11) DEFAULT 1,
                last_download DATETIME,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "CREATE TABLE IF NOT EXISTS support_tickets (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                user_id INT(11) NOT NULL,
                subject VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                status ENUM('open', 'in_progress', 'resolved', 'closed') DEFAULT 'open',
                priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "CREATE TABLE IF NOT EXISTS ticket_replies (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                ticket_id INT(11) NOT NULL,
                user_id INT(11) NOT NULL,
                message TEXT NOT NULL,
                is_admin BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        ];

        foreach ($tables as $table) {
            if (!$this->conn->query($table)) {
                error_log("Table creation error: " . $this->conn->error);
            }
        }
        
        $this->insertDefaultProducts();
    }

    private function insertDefaultProducts() {
        $check = $this->conn->query("SELECT COUNT(*) as count FROM products");
        $row = $check->fetch_assoc();
        
        if ($row['count'] == 0) {
            $products = [
                [
                    'Enterprise CRM Suite', 
                    'Kurumsal müşteri ilişkileri yönetimi çözümü', 
                    499.00, 
                    'pro',
                    'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    '2.1.0',
                    '245 MB'
                ],
                [
                    'AI Analytics Platform', 
                    'Yapay zeka destekli veri analiz platformu', 
                    799.00, 
                    'pro_max',
                    'https://images.unsplash.com/photo-1555949963-aa79dcee981c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    '1.5.2',
                    '189 MB'
                ],
                [
                    'Blockchain Security Suite', 
                    'Blockchain tabanlı güvenlik çözümü', 
                    1299.00, 
                    'ultimate',
                    'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    '3.0.1',
                    '356 MB'
                ],
                [
                    'Cloud Management Console', 
                    'Çoklu bulut yönetim ve izleme platformu', 
                    599.00, 
                    'pro',
                    'https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    '2.3.4',
                    '312 MB'
                ],
                [
                    'Mobile Banking Framework', 
                    'Güvenli mobil bankacılık çözümü', 
                    899.00, 
                    'pro_max',
                    'https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    '1.8.7',
                    '278 MB'
                ]
            ];
            
            $stmt = $this->conn->prepare("INSERT INTO products (name, description, price, required_plan, image_url, version, file_size) VALUES (?, ?, ?, ?, ?, ?, ?)");
            
            foreach ($products as $product) {
                $stmt->bind_param("ssdssss", $product[0], $product[1], $product[2], $product[3], $product[4], $product[5], $product[6]);
                $stmt->execute();
            }
        }
    }

    private function createFallbackFiles() {
        if (!is_dir('data')) {
            mkdir('data', 0777, true);
        }
        
        $default_files = [
            'users.json' => [],
            'products.json' => [],
            'orders.json' => [],
            'downloads.json' => [],
            'tickets.json' => []
        ];
        
        foreach ($default_files as $file => $content) {
            if (!file_exists("data/$file")) {
                file_put_contents("data/$file", json_encode($content, JSON_PRETTY_PRINT));
            }
        }
    }

    public function query($sql, $params = []) {
        try {
            if (!empty($params)) {
                $stmt = $this->conn->prepare($sql);
                if ($stmt === false) {
                    throw new Exception("SQL prepare error: " . $this->conn->error);
                }
                
                $types = str_repeat('s', count($params));
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $result = $stmt->get_result();
                $stmt->close();
                return $result;
            } else {
                return $this->conn->query($sql);
            }
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    public function getLastInsertId() {
        return $this->conn->insert_id;
    }

    public function escape($value) {
        return $this->conn->real_escape_string($value);
    }

    public function beginTransaction() {
        return $this->conn->begin_transaction();
    }

    public function commit() {
        return $this->conn->commit();
    }

    public function rollback() {
        return $this->conn->rollback();
    }
}
?>