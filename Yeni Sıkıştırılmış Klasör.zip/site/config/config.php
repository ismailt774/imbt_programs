<?php
// Site Genel Ayarları
define('SITE_NAME', 'IMBTSoft');
define('SITE_URL', 'https://imbtsoft.rf.gd'); // Domaininizi buraya yazın
define('SITE_EMAIL', 'itekeli42@outlook.com.tr');
define('SITE_PHONE', '+90 (555) 123 45 67');

// Güvenlik Ayarları
define('CSRF_TOKEN_LIFETIME', 3600); // 1 saat
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900); // 15 dakika

// Dosya Yükleme Ayarları
define('MAX_FILE_SIZE', 10485760); // 10MB
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'zip']);
define('UPLOAD_PATH', 'assets/uploads/');

// Email Ayarları
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-password');
define('SMTP_ENCRYPTION', 'tls');

// Ödeme Ayarları (Demo için)
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_your_stripe_key');
define('STRIPE_SECRET_KEY', 'sk_test_your_stripe_secret');

// Geliştirme Ayarları
define('DEBUG_MODE', true);
define('LOG_ERRORS', true);
define('ERROR_LOG_FILE', 'logs/errors.log');

// Dil Ayarları
define('DEFAULT_LANGUAGE', 'tr');
define('AVAILABLE_LANGUAGES', ['tr', 'en', 'de']);

// Plan Fiyatları
$plan_prices = [
    'personal' => 0,
    'lite' => 29,
    'pro' => 79,
    'pro_max' => 149,
    'ultimate' => 299
];

// Plan Özellikleri
$plan_features = [
    'personal' => [
        'users' => 1,
        'products' => 3,
        'support' => 'basic',
        'storage' => '1GB'
    ],
    'lite' => [
        'users' => 5,
        'products' => 10,
        'support' => 'basic',
        'storage' => '5GB'
    ],
    'pro' => [
        'users' => 10,
        'products' => 'all',
        'support' => 'priority',
        'storage' => '20GB'
    ],
    'pro_max' => [
        'users' => 25,
        'products' => 'all',
        'support' => 'priority',
        'storage' => '50GB'
    ],
    'ultimate' => [
        'users' => 'unlimited',
        'products' => 'all',
        'support' => '24/7',
        'storage' => '100GB'
    ]
];

// Hata Yönetimi
function errorHandler($errno, $errstr, $errfile, $errline) {
    if (DEBUG_MODE) {
        echo "<div class='alert alert-danger'>";
        echo "<strong>Error:</strong> $errstr<br>";
        echo "<strong>File:</strong> $errfile<br>";
        echo "<strong>Line:</strong> $errline";
        echo "</div>";
    }
    
    if (LOG_ERRORS) {
        $log_message = date('Y-m-d H:i:s') . " - Error: $errstr in $errfile on line $errline\n";
        error_log($log_message, 3, ERROR_LOG_FILE);
    }
    
    return true;
}

set_error_handler("errorHandler");

// Oturum Ayarları
session_set_cookie_params([
    'lifetime' => 86400, // 24 saat
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'],
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Strict'
]);

// Zaman Dilimi
date_default_timezone_set('Europe/Istanbul');

// Gerekli Klasörleri Oluştur
function createRequiredDirectories() {
    $directories = [
        'assets/uploads',
        'assets/images/products',
        'logs',
        'data'
    ];
    
    foreach ($directories as $directory) {
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }
    }
}

createRequiredDirectories();
?>