<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_data = [
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'password' => $_POST['password'],
        'company' => trim($_POST['company'] ?? ''),
        'phone' => trim($_POST['phone'] ?? '')
    ];
    
    $result = $userManager->register($user_data);
    
    if ($result['success']) {
        header('Location: ../dashboard/');
        exit;
    } else {
        $message = $translator->translate($result['message']);
        $message_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('register'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card">
                    <div class="auth-header text-center mb-4">
                        <a href="../index.php" class="auth-logo">
                            <i class="fas fa-code me-2"></i>
                            <span>IMBTSoft</span>
                        </a>
                        <h2 class="auth-title"><?php echo $translator->translate('register'); ?></h2>
                        <p class="text-muted"><?php echo $translator->translate('create_account'); ?></p>
                    </div>

                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type === 'error' ? 'danger' : 'success'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="auth-form">
                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo $translator->translate('full_name'); ?> *</label>
                            <input type="text" class="form-control" id="name" name="name" required 
                                   value="<?php echo $_POST['name'] ?? ''; ?>">
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label"><?php echo $translator->translate('email_address'); ?> *</label>
                            <input type="email" class="form-control" id="email" name="email" required
                                   value="<?php echo $_POST['email'] ?? ''; ?>">
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label"><?php echo $translator->translate('password'); ?> *</label>
                            <input type="password" class="form-control" id="password" name="password" required
                                   minlength="6">
                            <div class="form-text"><?php echo $translator->translate('password_requirements'); ?></div>
                        </div>

                        <div class="mb-3">
                            <label for="company" class="form-label"><?php echo $translator->translate('company_name'); ?></label>
                            <input type="text" class="form-control" id="company" name="company"
                                   value="<?php echo $_POST['company'] ?? ''; ?>">
                        </div>

                        <div class="mb-4">
                            <label for="phone" class="form-label"><?php echo $translator->translate('phone_number'); ?></label>
                            <input type="tel" class="form-control" id="phone" name="phone"
                                   value="<?php echo $_POST['phone'] ?? ''; ?>">
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-user-plus me-2"></i>
                                <?php echo $translator->translate('register'); ?>
                            </button>
                        </div>
                    </form>

                    <div class="auth-footer text-center mt-4">
                        <p class="text-muted">
                            <?php echo $translator->translate('already_have_account'); ?>
                            <a href="login.php" class="text-primary"><?php echo $translator->translate('login_here'); ?></a>
                        </p>
                    </div>

                    <div class="text-center mt-3">
                        <a href="../index.php" class="text-muted">
                            <i class="fas fa-arrow-left me-1"></i>
                            <?php echo $translator->translate('back_to_home'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/auth.js"></script>
</body>
</html>