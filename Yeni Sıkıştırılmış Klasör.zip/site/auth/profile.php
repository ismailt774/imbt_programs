<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

if (!$userManager->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user = $userManager->getUser();
$message = '';
$message_type = '';

// Profil güncelleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $user_data = [
        'name' => trim($_POST['name']),
        'company' => trim($_POST['company']),
        'phone' => trim($_POST['phone']),
        'company_size' => $_POST['company_size'],
        'industry' => $_POST['industry']
    ];
    
    if ($userManager->updateUser($user['id'], $user_data)) {
        $message = $translator->translate('profile_updated');
        $message_type = 'success';
        // Kullanıcı bilgilerini yenile
        $user = $userManager->getUser();
    } else {
        $message = $translator->translate('profile_update_error');
        $message_type = 'error';
    }
}

// Şifre değiştirme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password !== $confirm_password) {
        $message = $translator->translate('passwords_not_match');
        $message_type = 'error';
    } else {
        $result = $userManager->changePassword($user['id'], $current_password, $new_password);
        $message = $translator->translate($result['message']);
        $message_type = $result['success'] ? 'success' : 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('profile'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <?php include '../includes/navigation.php'; ?>

    <div class="container py-5 mt-5">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="glass-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2><?php echo $translator->translate('profile_settings'); ?></h2>
                        <a href="../dashboard/" class="btn btn-outline-light">
                            <i class="fas fa-arrow-left me-2"></i><?php echo $translator->translate('back_to_dashboard'); ?>
                        </a>
                    </div>

                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type === 'error' ? 'danger' : 'success'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Profil Bilgileri -->
                    <div class="mb-5">
                        <h4 class="mb-4"><?php echo $translator->translate('personal_information'); ?></h4>
                        <form method="POST">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label"><?php echo $translator->translate('full_name'); ?> *</label>
                                    <input type="text" class="form-control" id="name" name="name" 
                                           value="<?php echo htmlspecialchars($user['name']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label"><?php echo $translator->translate('email_address'); ?></label>
                                    <input type="email" class="form-control" id="email" 
                                           value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                                    <div class="form-text"><?php echo $translator->translate('email_cannot_change'); ?></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="company" class="form-label"><?php echo $translator->translate('company_name'); ?></label>
                                    <input type="text" class="form-control" id="company" name="company"
                                           value="<?php echo htmlspecialchars($user['company'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label"><?php echo $translator->translate('phone_number'); ?></label>
                                    <input type="tel" class="form-control" id="phone" name="phone"
                                           value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="company_size" class="form-label"><?php echo $translator->translate('company_size'); ?></label>
                                    <select class="form-control" id="company_size" name="company_size">
                                        <option value=""><?php echo $translator->translate('select_company_size'); ?></option>
                                        <option value="1-10" <?php echo ($user['company_size'] ?? '') === '1-10' ? 'selected' : ''; ?>>1-10</option>
                                        <option value="11-50" <?php echo ($user['company_size'] ?? '') === '11-50' ? 'selected' : ''; ?>>11-50</option>
                                        <option value="51-200" <?php echo ($user['company_size'] ?? '') === '51-200' ? 'selected' : ''; ?>>51-200</option>
                                        <option value="201-500" <?php echo ($user['company_size'] ?? '') === '201-500' ? 'selected' : ''; ?>>201-500</option>
                                        <option value="501+" <?php echo ($user['company_size'] ?? '') === '501+' ? 'selected' : ''; ?>>501+</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="industry" class="form-label"><?php echo $translator->translate('industry'); ?></label>
                                    <select class="form-control" id="industry" name="industry">
                                        <option value=""><?php echo $translator->translate('select_industry'); ?></option>
                                        <option value="technology" <?php echo ($user['industry'] ?? '') === 'technology' ? 'selected' : ''; ?>>Technology</option>
                                        <option value="finance" <?php echo ($user['industry'] ?? '') === 'finance' ? 'selected' : ''; ?>>Finance</option>
                                        <option value="healthcare" <?php echo ($user['industry'] ?? '') === 'healthcare' ? 'selected' : ''; ?>>Healthcare</option>
                                        <option value="education" <?php echo ($user['industry'] ?? '') === 'education' ? 'selected' : ''; ?>>Education</option>
                                        <option value="retail" <?php echo ($user['industry'] ?? '') === 'retail' ? 'selected' : ''; ?>>Retail</option>
                                        <option value="other" <?php echo ($user['industry'] ?? '') === 'other' ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i><?php echo $translator->translate('update_profile'); ?>
                            </button>
                        </form>
                    </div>

                    <!-- Şifre Değiştirme -->
                    <div class="mb-4">
                        <h4 class="mb-4"><?php echo $translator->translate('change_password'); ?></h4>
                        <form method="POST">
                            <input type="hidden" name="action" value="change_password">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="current_password" class="form-label"><?php echo $translator->translate('current_password'); ?> *</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="new_password" class="form-label"><?php echo $translator->translate('new_password'); ?> *</label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="confirm_password" class="form-label"><?php echo $translator->translate('confirm_password'); ?> *</label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="6">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-key me-2"></i><?php echo $translator->translate('change_password'); ?>
                            </button>
                        </form>
                    </div>

                    <!-- Hesap Bilgileri -->
                    <div class="mt-5 pt-4 border-top">
                        <h4 class="mb-4"><?php echo $translator->translate('account_information'); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong><?php echo $translator->translate('member_since'); ?>:</strong><br>
                                <?php echo date('d.m.Y', strtotime($user['created_at'])); ?></p>
                                
                                <p><strong><?php echo $translator->translate('last_login'); ?>:</strong><br>
                                <?php echo $user['last_login'] ? date('d.m.Y H:i', strtotime($user['last_login'])) : $translator->translate('never'); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong><?php echo $translator->translate('account_status'); ?>:</strong><br>
                                <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'warning'; ?>">
                                    <?php echo $translator->translate($user['status']); ?>
                                </span></p>
                                
                                <p><strong><?php echo $translator->translate('email_verified'); ?>:</strong><br>
                                <span class="badge bg-<?php echo $user['email_verified'] ? 'success' : 'warning'; ?>">
                                    <?php echo $user['email_verified'] ? $translator->translate('yes') : $translator->translate('no'); ?>
                                </span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>