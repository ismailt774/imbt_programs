<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

$message = '';
$message_type = '';
$token = $_GET['token'] ?? '';

if (empty($token)) {
    $message = $translator->translate('invalid_reset_link');
    $message_type = 'error';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password !== $confirm_password) {
        $message = $translator->translate('passwords_not_match');
        $message_type = 'error';
    } else {
        $result = $userManager->resetPassword($token, $new_password);
        $message = $translator->translate($result['message']);
        $message_type = $result['success'] ? 'success' : 'error';
        
        if ($result['success']) {
            $token = ''; // Token'ı temizle
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('reset_password'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card">
                    <div class="auth-header text-center mb-4">
                        <a href="../index.php" class="auth-logo">
                            <i class="fas fa-code me-2"></i>
                            <span>IMBTSoft</span>
                        </a>
                        <h2 class="auth-title"><?php echo $translator->translate('reset_password'); ?></h2>
                        <p class="text-muted"><?php echo $translator->translate('enter_new_password'); ?></p>
                    </div>

                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type === 'error' ? 'danger' : 'success'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($token) && $message_type !== 'success'): ?>
                    <form method="POST" class="auth-form">
                        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label"><?php echo $translator->translate('new_password'); ?> *</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                            <div class="form-text"><?php echo $translator->translate('password_requirements'); ?></div>
                        </div>

                        <div class="mb-4">
                            <label for="confirm_password" class="form-label"><?php echo $translator->translate('confirm_password'); ?> *</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="6">
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-key me-2"></i>
                                <?php echo $translator->translate('reset_password'); ?>
                            </button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <div class="auth-footer text-center mt-4">
                        <p class="text-muted">
                            <?php echo $translator->translate('back_to'); ?>
                            <a href="login.php" class="text-primary"><?php echo $translator->translate('login'); ?></a>
                        </p>
                    </div>

                    <div class="text-center mt-3">
                        <a href="../index.php" class="text-muted">
                            <i class="fas fa-arrow-left me-1"></i>
                            <?php echo $translator->translate('back_to_home'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>