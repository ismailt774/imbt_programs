<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    
    $result = $userManager->requestPasswordReset($email);
    $message = $translator->translate($result['message']);
    $message_type = $result['success'] ? 'success' : 'error';
}
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('forgot_password'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card">
                    <div class="auth-header text-center mb-4">
                        <a href="../index.php" class="auth-logo">
                            <i class="fas fa-code me-2"></i>
                            <span>IMBTSoft</span>
                        </a>
                        <h2 class="auth-title"><?php echo $translator->translate('forgot_password'); ?></h2>
                        <p class="text-muted"><?php echo $translator->translate('enter_email_for_reset'); ?></p>
                    </div>

                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type === 'error' ? 'danger' : 'success'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="auth-form">
                        <div class="mb-4">
                            <label for="email" class="form-label"><?php echo $translator->translate('email_address'); ?></label>
                            <input type="email" class="form-control" id="email" name="email" required
                                   value="<?php echo $_POST['email'] ?? ''; ?>">
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-paper-plane me-2"></i>
                                <?php echo $translator->translate('send_reset_link'); ?>
                            </button>
                        </div>
                    </form>

                    <div class="auth-footer text-center mt-4">
                        <p class="text-muted">
                            <?php echo $translator->translate('remember_password'); ?>
                            <a href="login.php" class="text-primary"><?php echo $translator->translate('login_here'); ?></a>
                        </p>
                    </div>

                    <div class="text-center mt-3">
                        <a href="../index.php" class="text-muted">
                            <i class="fas fa-arrow-left me-1"></i>
                            <?php echo $translator->translate('back_to_home'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>