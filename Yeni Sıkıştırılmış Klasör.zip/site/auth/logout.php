<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';

$database = new Database();
$userManager = new UserManager($database);

// Çıkış yap
$userManager->logout();

// Başarı mesajı
$_SESSION['message'] = 'Çıkış yapıldı.';
$_SESSION['message_type'] = 'success';

// Ana sayfaya yönlendir
header('Location: ../index.php');
exit;
?>