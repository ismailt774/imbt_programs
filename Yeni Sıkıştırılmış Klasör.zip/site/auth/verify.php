<?php
session_start();
require_once '../config/database.php';
require_once '../classes/UserManager.php';
require_once '../classes/LanguageManager.php';
require_once '../classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

$message = '';
$message_type = '';

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    if ($userManager->verifyEmail($token)) {
        $message = $translator->translate('email_verified');
        $message_type = 'success';
    } else {
        $message = $translator->translate('invalid_verification_token');
        $message_type = 'error';
    }
} else {
    $message = $translator->translate('no_verification_token');
    $message_type = 'error';
}
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translator->translate('verify_email'); ?> - IMBTSoft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card text-center">
                    <div class="auth-header mb-4">
                        <a href="../index.php" class="auth-logo">
                            <i class="fas fa-code me-2"></i>
                            <span>IMBTSoft</span>
                        </a>
                        <h2 class="auth-title"><?php echo $translator->translate('verify_email'); ?></h2>
                    </div>

                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type === 'error' ? 'danger' : 'success'; ?>">
                            <i class="fas fa-<?php echo $message_type === 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <div class="d-grid gap-2 mt-4">
                        <?php if ($message_type === 'success'): ?>
                            <a href="login.php" class="btn btn-primary">
                                <i class="fas fa-sign-in-alt me-2"></i>
                                <?php echo $translator->translate('login_now'); ?>
                            </a>
                        <?php else: ?>
                            <a href="../index.php" class="btn btn-outline-primary">
                                <i class="fas fa-home me-2"></i>
                                <?php echo $translator->translate('back_to_home'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>