<?php
session_start();
require_once 'config/database.php';
require_once 'classes/UserManager.php';
require_once 'classes/ProductManager.php';
require_once 'classes/LanguageManager.php';
require_once 'classes/Translator.php';

$database = new Database();
$userManager = new UserManager($database);
$productManager = new ProductManager($database);
$languageManager = new LanguageManager();
$translator = new Translator($languageManager->getCurrentLanguage());

$plans = [
    'personal' => ['name' => 'personal_plan', 'price' => 0],
    'lite' => ['name' => 'lite_plan', 'price' => 29],
    'pro' => ['name' => 'pro_plan', 'price' => 79],
    'pro_max' => ['name' => 'pro_max_plan', 'price' => 149],
    'ultimate' => ['name' => 'ultimate_plan', 'price' => 299]
];

$current_user = $userManager->getUser();
$current_plan = $current_user ? $current_user['plan'] : 'personal';
$popular_products = $productManager->getPopularProducts(3);
$all_products = $productManager->getProducts();
?>

<!DOCTYPE html>
<html lang="<?php echo $translator->getLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMBTSoft | Enterprise Software Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <?php include 'includes/navigation.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center min-vh-100">
                <div class="col-lg-6" data-aos="fade-right">
                    <h1 class="display-3 fw-bold mb-4">
                        <span class="gradient-text">Enterprise</span><br>
                        Software Solutions
                    </h1>
                    <p class="lead mb-5"><?php echo $translator->translate('hero_subtitle'); ?></p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="products/" class="btn btn-gradient btn-lg">
                            <i class="fas fa-rocket me-2"></i><?php echo $translator->translate('view_products'); ?>
                        </a>
                        <a href="pricing/" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-crown me-2"></i><?php echo $translator->translate('pricing'); ?>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <div class="glass-card floating-element">
                        <div class="row text-center">
                            <div class="col-4">
                                <div class="stats-number">50+</div>
                                <small><?php echo $translator->translate('completed_projects'); ?></small>
                            </div>
                            <div class="col-4">
                                <div class="stats-number">15+</div>
                                <small><?php echo $translator->translate('years_experience'); ?></small>
                            </div>
                            <div class="col-4">
                                <div class="stats-number">100+</div>
                                <small><?php echo $translator->translate('happy_clients'); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section py-5">
        <div class="container">
            <div class="row mb-5">
                <div class="col-12 text-center">
                    <h2 class="section-title" data-aos="fade-up"><?php echo $translator->translate('why_choose_us'); ?></h2>
                    <p class="text-muted" data-aos="fade-up" data-aos-delay="100">
                        <?php echo $translator->translate('features_description'); ?>
                    </p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-4" data-aos="fade-up">
                    <div class="glass-card text-center h-100">
                        <div class="service-icon mx-auto">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h4><?php echo $translator->translate('secure'); ?></h4>
                        <p class="text-muted"><?php echo $translator->translate('secure_description'); ?></p>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="glass-card text-center h-100">
                        <div class="service-icon mx-auto">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <h4><?php echo $translator->translate('fast'); ?></h4>
                        <p class="text-muted"><?php echo $translator->translate('fast_description'); ?></p>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="glass-card text-center h-100">
                        <div class="service-icon mx-auto">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h4><?php echo $translator->translate('support'); ?></h4>
                        <p class="text-muted"><?php echo $translator->translate('support_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Popular Products Section -->
    <section class="products-section py-5 bg-dark">
        <div class="container">
            <div class="row mb-5">
                <div class="col-12 text-center">
                    <h2 class="section-title" data-aos="fade-up"><?php echo $translator->translate('popular_products'); ?></h2>
                    <p class="text-muted" data-aos="fade-up" data-aos-delay="100">
                        <?php echo $translator->translate('popular_products_description'); ?>
                    </p>
                </div>
            </div>
            <div class="row g-4">
                <?php foreach ($popular_products as $product): ?>
                <div class="col-md-4" data-aos="fade-up">
                    <div class="product-card">
                        <div class="product-image" style="background-image: url('<?php echo $product['image_url']; ?>')">
                            <span class="plan-badge"><?php echo $translator->translate($plans[$product['required_plan']]['name']); ?></span>
                        </div>
                        <div class="p-4">
                            <h5><?php echo $product['name']; ?></h5>
                            <p class="text-muted"><?php echo $product['description']; ?></p>
                            <div class="product-meta">
                                <span><i class="fas fa-code-branch me-1"></i> v<?php echo $product['version']; ?></span>
                                <span><i class="fas fa-hdd me-1"></i> <?php echo $product['file_size']; ?></span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <span class="h5 mb-0 text-gradient">$<?php echo $product['price']; ?></span>
                                <?php if ($userManager->isLoggedIn()): ?>
                                    <?php if ($userManager->canAccessProduct($current_plan, $product['required_plan'])): ?>
                                        <a href="products/download.php?id=<?php echo $product['id']; ?>" class="btn btn-gradient btn-sm">
                                            <i class="fas fa-download me-1"></i><?php echo $translator->translate('download'); ?>
                                        </a>
                                    <?php else: ?>
                                        <a href="pricing/" class="btn btn-outline-light btn-sm">
                                            <?php echo $translator->translate('upgrade_now'); ?>
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="auth/register.php" class="btn btn-outline-light btn-sm">
                                        <?php echo $translator->translate('get_access'); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="row mt-5">
                <div class="col-12 text-center">
                    <a href="products/" class="btn btn-gradient btn-lg">
                        <i class="fas fa-eye me-2"></i><?php echo $translator->translate('view_all_products'); ?>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section py-5">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8">
                    <div class="glass-card py-5">
                        <h2 class="mb-4"><?php echo $translator->translate('ready_to_start'); ?></h2>
                        <p class="text-muted mb-4"><?php echo $translator->translate('cta_description'); ?></p>
                        <div class="d-flex flex-wrap gap-3 justify-content-center">
                            <?php if ($userManager->isLoggedIn()): ?>
                                <a href="dashboard/" class="btn btn-gradient btn-lg">
                                    <i class="fas fa-tachometer-alt me-2"></i><?php echo $translator->translate('go_to_dashboard'); ?>
                                </a>
                            <?php else: ?>
                                <a href="auth/register.php" class="btn btn-gradient btn-lg">
                                    <i class="fas fa-user-plus me-2"></i><?php echo $translator->translate('register'); ?>
                                </a>
                                <a href="auth/login.php" class="btn btn-outline-light btn-lg">
                                    <i class="fas fa-sign-in-alt me-2"></i><?php echo $translator->translate('login'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });
    </script>
</body>
</html>