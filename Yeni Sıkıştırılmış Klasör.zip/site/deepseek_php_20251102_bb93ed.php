<?php
// test_password.php - Şifre test scripti
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>🔐 Database Şifre Testi</h3>";
echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 10px;'>";

// Olası şifreleri test et
$possible_passwords = [
    'Ismail1453',
    'Ismail2012!', 
    'Ismail2012',
    'ismail1453',
    'Ismail',
    '1453',
    '' // boş şifre
];

$host = 'sql306.infinityfree.com';
$username = 'if0_39963970';
$database = 'if0_39963970_imbtsoftdb';

foreach ($possible_passwords as $password) {
    echo "<h4>Şifre test ediliyor: '<strong>" . ($password ? $password : 'BOŞ') . "'</strong></h4>";
    
    try {
        $conn = new mysqli($host, $username, $password, $database);
        
        if ($conn->connect_error) {
            echo "<div style='color: red;'>❌ Başarısız: " . $conn->connect_error . "</div>";
        } else {
            echo "<div style='color: green; font-weight: bold;'>✅ BAŞARILI! Doğru şifre: <strong>" . $password . "</strong></div>";
            $conn->close();
            break;
        }
        
    } catch (Exception $e) {
        echo "<div style='color: red;'>❌ Hata: " . $e->getMessage() . "</div>";
    }
    
    echo "<hr>";
}

echo "</div>";
?>